<?php
use FastCrud\Crud;
use FastCrud\DatabaseEditor;
use Mzgs\Core\CoreCallback;
use Mzgs\Core\Navigation\NavigationRepository;
use PhpHelper\{App, AuthManager, Config, Files, Format, Http, TwigHelper};


$fileManagerDefaultRelativeRoot = 'app/public';
$fileManagerProjectRoot         = ROOT;

$fileManagerNormaliseSlashes = static function (string $path): string
{
    return str_replace('\\', '/', $path);
};

$fileManagerSanitiseConfigValue = static function (?string $value) use ($fileManagerDefaultRelativeRoot, $fileManagerNormaliseSlashes): string
{
    $clean = trim($fileManagerNormaliseSlashes((string) ($value ?? '')));
    if ($clean === '') {
        return $fileManagerDefaultRelativeRoot;
    }

    return trim($clean, '/');
};

$fileManagerRelativeToAbsolute = static function (string $relative) use ($fileManagerProjectRoot): string
{
    return $fileManagerProjectRoot . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
};

$fileManagerResolveConfiguredRoot = static function (?string $value) use ($fileManagerSanitiseConfigValue, $fileManagerRelativeToAbsolute): array
{
    $relative = $fileManagerSanitiseConfigValue($value);
    $absolute = $fileManagerRelativeToAbsolute($relative);

    return [$absolute, $relative];
};

$fileManagerDescribeRoot = static function (string $absolute, string $relative) use ($fileManagerProjectRoot, $fileManagerDefaultRelativeRoot, $fileManagerNormaliseSlashes): array
{
    $normalizedAbsolute = $fileManagerNormaliseSlashes($absolute);
    $normalizedProject = $fileManagerNormaliseSlashes($fileManagerProjectRoot);

    if (!str_starts_with($normalizedAbsolute, $normalizedProject)) {
        $absolute           = $fileManagerProjectRoot . DIRECTORY_SEPARATOR . $fileManagerDefaultRelativeRoot;
        $relative           = $fileManagerDefaultRelativeRoot;
        $normalizedAbsolute = $fileManagerNormaliseSlashes($absolute);
    }

    $relativeFromProject = ltrim(substr($normalizedAbsolute, strlen($normalizedProject)), '/');
    if ($relativeFromProject === '') {
        $relativeFromProject = $relative;
    }

    $labelCandidate = $relativeFromProject !== '' ? basename($relativeFromProject) : basename($normalizedAbsolute);
    if ($labelCandidate === '' || $labelCandidate === '.' || $labelCandidate === DIRECTORY_SEPARATOR) {
        $labelCandidate = 'files';
    }

    return [
        'absolute' => $absolute,
        'config'   => $relative,
        'relative' => $relativeFromProject,
        'label'    => $labelCandidate,
        'default'  => $fileManagerDefaultRelativeRoot,
    ];
};

$fileManagerStoredRoot                         = Config::get('file_manager.root', $fileManagerDefaultRelativeRoot);
$fileManagerStoredRoot                         = is_string($fileManagerStoredRoot) ? $fileManagerStoredRoot : $fileManagerDefaultRelativeRoot;
[$fileManagerRoot, $fileManagerConfiguredRoot] = $fileManagerResolveConfiguredRoot($fileManagerStoredRoot);
Files::createDirectory($fileManagerRoot);
$fileManagerRoot           = realpath($fileManagerRoot) ?: $fileManagerRoot;
$fileManagerRootMeta       = $fileManagerDescribeRoot($fileManagerRoot, $fileManagerConfiguredRoot);
$fileManagerRoot           = $fileManagerRootMeta['absolute'];
$fileManagerConfiguredRoot = $fileManagerRootMeta['config'];
$fileManagerRootLabel      = $fileManagerRootMeta['label'];
Files::createDirectory($fileManagerRoot);

$fileManagerNormaliseRelative = static function (?string $path): string
{
    $value = trim((string) ($path ?? ''));
    if ($value === '') {
        return '';
    }

    $value = str_replace("\0", '', $value);
    $value = str_replace('\\', '/', $value);
    $value = preg_replace('#/+#', '/', $value) ?? $value;

    $segments = [];
    foreach (explode('/', $value) as $segment) {
        if ($segment === '' || $segment === '.') {
            continue;
        }

        if ($segment === '..') {
            array_pop($segments);
            continue;
        }

        $segments[] = $segment;
    }

    return implode('/', $segments);
};

$fileManagerResolvePath = static function (?string $relative) use ($fileManagerRoot, $fileManagerNormaliseRelative): array
{
    $normalised = $fileManagerNormaliseRelative($relative ?? '');
    $absolute = $fileManagerRoot;
    if ($normalised !== '') {
        $absolute .= DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $normalised);
    }

    return [$absolute, $normalised];
};

$fileManagerPathInRoot = static function (string $path) use ($fileManagerRoot, $fileManagerNormaliseSlashes): bool
{
    $normalizedRoot = rtrim($fileManagerNormaliseSlashes($fileManagerRoot), '/');
    $normalizedPath = rtrim($fileManagerNormaliseSlashes($path), '/');

    return $normalizedPath === $normalizedRoot || str_starts_with($normalizedPath, $normalizedRoot . '/');
};

$fileManagerValidateEntryName = static function (string $name): bool
{
    $trimmed = trim($name);
    if ($trimmed === '' || $trimmed === '.' || $trimmed === '..') {
        return false;
    }

    if (str_contains($trimmed, '\0') || str_contains($trimmed, '/') || str_contains($trimmed, '\\')) {
        return false;
    }

    return true;
};

$fileManagerSizeToBytes = static function (?string $value): ?int
{
    if ($value === null) {
        return null;
    }

    $trimmed = trim($value);
    if ($trimmed === '') {
        return null;
    }

    if (is_numeric($trimmed)) {
        return (int) $trimmed;
    }

    if (!preg_match('/^(\d+)([KMGTP]?)(B?)$/i', $trimmed, $matches)) {
        return null;
    }

    $number = (int) $matches[1];
    $unit = strtoupper($matches[2] ?? '');

    $multipliers = [
        ''  => 1,
        'K' => 1024,
        'M' => 1024 ** 2,
        'G' => 1024 ** 3,
        'T' => 1024 ** 4,
        'P' => 1024 ** 5,
    ];

    $multiplier = $multipliers[$unit] ?? null;
    if ($multiplier === null) {
        return null;
    }

    return $number * $multiplier;
};

$fileManagerIconClass = static function (string $extension, string $mime): string
{
    $ext = strtolower($extension);

    $map = [
        'pdf'   => 'fa-file-pdf',
        'doc'   => 'fa-file-word',
        'docx'  => 'fa-file-word',
        'rtf'   => 'fa-file-word',
        'odt'   => 'fa-file-word',
        'xls'   => 'fa-file-excel',
        'xlsx'  => 'fa-file-excel',
        'csv'   => 'fa-file-excel',
        'ods'   => 'fa-file-excel',
        'ppt'   => 'fa-file-powerpoint',
        'pptx'  => 'fa-file-powerpoint',
        'odp'   => 'fa-file-powerpoint',
        'zip'   => 'fa-file-zipper',
        'rar'   => 'fa-file-zipper',
        '7z'    => 'fa-file-zipper',
        'tar'   => 'fa-file-zipper',
        'gz'    => 'fa-file-zipper',
        'bz2'   => 'fa-file-zipper',
        'xz'    => 'fa-file-zipper',
        'json'  => 'fa-file-code',
        'xml'   => 'fa-file-code',
        'yml'   => 'fa-file-code',
        'yaml'  => 'fa-file-code',
        'js'    => 'fa-file-code',
        'jsx'   => 'fa-file-code',
        'ts'    => 'fa-file-code',
        'tsx'   => 'fa-file-code',
        'css'   => 'fa-file-code',
        'scss'  => 'fa-file-code',
        'sass'  => 'fa-file-code',
        'less'  => 'fa-file-code',
        'php'   => 'fa-file-code',
        'py'    => 'fa-file-code',
        'rb'    => 'fa-file-code',
        'java'  => 'fa-file-code',
        'c'     => 'fa-file-code',
        'cpp'   => 'fa-file-code',
        'cs'    => 'fa-file-code',
        'go'    => 'fa-file-code',
        'swift' => 'fa-file-code',
        'kt'    => 'fa-file-code',
        'rs'    => 'fa-file-code',
        'sh'    => 'fa-file-code',
        'sql'   => 'fa-file-code',
        'md'    => 'fa-file-lines',
        'txt'   => 'fa-file-lines',
        'log'   => 'fa-file-lines',
        'mp3'   => 'fa-file-audio',
        'wav'   => 'fa-file-audio',
        'ogg'   => 'fa-file-audio',
        'flac'  => 'fa-file-audio',
        'aac'   => 'fa-file-audio',
        'm4a'   => 'fa-file-audio',
        'mp4'   => 'fa-file-video',
        'mov'   => 'fa-file-video',
        'avi'   => 'fa-file-video',
        'mkv'   => 'fa-file-video',
        'webm'  => 'fa-file-video',
        'wmv'   => 'fa-file-video',
    ];

    if (isset($map[$ext])) {
        return $map[$ext];
    }

    if (str_starts_with($mime, 'image/')) {
        return 'fa-file-image';
    }
    if (str_starts_with($mime, 'audio/')) {
        return 'fa-file-audio';
    }
    if (str_starts_with($mime, 'video/')) {
        return 'fa-file-video';
    }
    if (str_starts_with($mime, 'text/')) {
        return 'fa-file-lines';
    }

    return 'fa-file';
};

$fileManagerCopyRecursive = static function (string $source, string $destination) use (&$fileManagerCopyRecursive): bool
{
    if (is_dir($source)) {
        if (!is_dir($destination) && !Files::createDirectory($destination)) {
            return false;
        }

        $entries = scandir($source);
        if ($entries === false) {
            return false;
        }

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }

            $sourceChild      = $source . DIRECTORY_SEPARATOR . $entry;
            $destinationChild = $destination . DIRECTORY_SEPARATOR . $entry;

            if (!$fileManagerCopyRecursive($sourceChild, $destinationChild)) {
                return false;
            }
        }

        return true;
    }

    if (!is_file($source)) {
        return false;
    }

    return Files::copy($source, $destination);
};

$fileManagerAddToArchive = static function ($zip, string $sourcePath, string $relativePath) use (&$fileManagerAddToArchive, $fileManagerNormaliseSlashes): bool
{
    if (!($zip instanceof \ZipArchive)) {
        return false;
    }

    if (is_link($sourcePath)) {
        return false;
    }

    if (is_dir($sourcePath)) {
        if (!is_readable($sourcePath)) {
            return false;
        }

        $normalizedRelative = trim($fileManagerNormaliseSlashes($relativePath), '/');
        $directoryEntry = $normalizedRelative === '' ? '' : str_replace('\\', '/', $normalizedRelative);

        if ($directoryEntry !== '') {
            $directoryKey     = rtrim($directoryEntry, '/');
            $zipDirectoryName = $directoryKey === '' ? '' : $directoryKey . '/';

            if ($directoryKey !== '' && $zip->locateName($zipDirectoryName) === false) {
                if (!$zip->addEmptyDir($directoryKey)) {
                    return false;
                }
            }
        }

        $entries = scandir($sourcePath);
        if ($entries === false) {
            return false;
        }

        foreach ($entries as $entry) {
            if ($entry === '.' || $entry === '..') {
                continue;
            }

            $childSource   = $sourcePath . DIRECTORY_SEPARATOR . $entry;
            $childRelative = $directoryEntry === '' ? $entry : $directoryEntry . '/' . $entry;

            if (!$fileManagerAddToArchive($zip, $childSource, $childRelative)) {
                return false;
            }
        }
        return true;
    }

    if (is_file($sourcePath)) {
        if (!is_readable($sourcePath)) {
            return false;
        }

        $entryName = trim($fileManagerNormaliseSlashes($relativePath), '/');
        if ($entryName === '') {
            $entryName = basename($sourcePath);
        }
        $entryName = str_replace('\\', '/', $entryName);

        return $zip->addFile($sourcePath, $entryName);
    }

    return false;
};

$fileManagerPathIsDescendant = static function (string $parent, string $child, bool $allowSame = false) use ($fileManagerNormaliseSlashes): bool
{
    $normalizedParent = rtrim($fileManagerNormaliseSlashes($parent), '/');
    $normalizedChild = rtrim($fileManagerNormaliseSlashes($child), '/');

    if ($normalizedParent === '' || $normalizedChild === '') {
        return false;
    }

    if ($normalizedParent === $normalizedChild) {
        return $allowSame;
    }

    return str_starts_with($normalizedChild, $normalizedParent . '/');
};

$router->get('/login', function ()
{
    if (AuthManager::isLoggedIn()) {
        Http::redirect('/');
        return;
    }
    $defaults = [
        'title'   => 'Account Access',
        'errors'  => [
            'login' => [],
        ],
        'old'     => [
            'login' => [
                'email'    => '',
                'remember' => false,
            ],
        ],
        'success' => null,
    ];

    $flash = $_SESSION['auth_flash'] ?? [];
    if ($flash) {
        unset($_SESSION['auth_flash']);
    }

    $querySuccess = null;
    if (isset($_GET['success'])) {
        $querySuccess = trim((string) $_GET['success']);
    }

    $context = array_replace_recursive($defaults, $flash, [
        'success' => $querySuccess ?: null,
    ]);

    echo TwigHelper::render('auth.twig', $context);
});

$router->post('/login', function ()
{
    $email    = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $remember = !empty($_POST['remember']);

    $errors = [];

    if ($email === '') {
        $errors[] = 'Email is required.';
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Please enter a valid email address.';
    }

    if ($password === '') {
        $errors[] = 'Password is required.';
    }

    if (!$errors) {
        $user = AuthManager::login($email, $password, $remember);

        if ($user) {
            Http::redirect('/');
            return;
        }

        $errors[] = 'Invalid email or password.';
    }

    $_SESSION['auth_flash'] = [
        'errors' => [
            'login' => $errors,
        ],
        'old'    => [
            'login' => [
                'email'    => $email,
                'remember' => $remember,
            ],
        ],
    ];

    Http::redirect('/login');
    return;
});

$router->match('GET|POST', '/logout', function ()
{
    AuthManager::logout();

    Http::redirect('/login');
    return;
});

$router->get('/admin/navigation', function ()
{
    $flash = $_SESSION['navigation_flash'] ?? [];
    unset($_SESSION['navigation_flash']);

    $groups   = NavigationRepository::grouped();
    $sections = array_keys($groups);
    if (!in_array('Main', $sections, true)) {
        $sections[] = 'Main';
    }
    sort($sections);

    $createDefaults = array_merge([
        'label'   => '',
        'url'     => '',
        'icon'    => '',
        'section' => 'Main',
    ], $flash['old_create'] ?? []);

    echo TwigHelper::render('admin/navigation.twig', [
        'title'             => 'Navigation Manager',
        'navigation_groups' => $groups,
        'sections'          => $sections,
        'flash'             => [
            'success' => $flash['success'] ?? null,
            'error'   => $flash['error'] ?? null,
        ],
        'create_defaults'   => $createDefaults,
    ]);
});

$router->post('/admin/navigation/create', function ()
{
    $data = [
        'label'   => $_POST['label'] ?? '',
        'url'     => $_POST['url'] ?? '',
        'icon'    => $_POST['icon'] ?? '',
        'section' => $_POST['section'] ?? 'Main',
    ];

    try {
        NavigationRepository::create($data);
        $_SESSION['navigation_flash'] = [
            'success' => 'Navigation link added successfully.',
        ];
    } catch (\InvalidArgumentException $e) {
        $_SESSION['navigation_flash'] = [
            'error'      => $e->getMessage(),
            'old_create' => $data,
        ];
    } catch (\Throwable $e) {
        $_SESSION['navigation_flash'] = [
            'error'      => 'Unable to add navigation link. Please try again.',
            'old_create' => $data,
        ];
    }

    Http::redirect('/admin/navigation');
});

$router->post('/admin/navigation/(\d+)/update', function ($id)
{
    $id   = (int) $id;
    $data = [
        'label'   => $_POST['label'] ?? '',
        'url'     => $_POST['url'] ?? '',
        'icon'    => $_POST['icon'] ?? '',
        'section' => $_POST['section'] ?? 'Main',
    ];

    try {
        if (!NavigationRepository::update($id, $data)) {
            $_SESSION['navigation_flash'] = [
                'error' => 'Navigation link could not be updated.',
            ];
        } else {
            $_SESSION['navigation_flash'] = [
                'success' => 'Navigation link updated successfully.',
            ];
        }
    } catch (\InvalidArgumentException $e) {
        $_SESSION['navigation_flash'] = [
            'error' => $e->getMessage(),
        ];
    } catch (\Throwable $e) {
        $_SESSION['navigation_flash'] = [
            'error' => 'Unable to update navigation link. Please try again.',
        ];
    }

    Http::redirect('/admin/navigation');
});

$router->post('/admin/navigation/(\d+)/duplicate', function ($id)
{
    $id = (int) $id;

    try {
        $newId = NavigationRepository::duplicate($id);

        if (!$newId) {
            $_SESSION['navigation_flash'] = [
                'error' => 'Navigation link could not be duplicated.',
            ];
        } else {
            $_SESSION['navigation_flash'] = [
                'success' => 'Navigation link duplicated successfully.',
            ];
        }
    } catch (\Throwable $e) {
        $_SESSION['navigation_flash'] = [
            'error' => 'Unable to duplicate navigation link. Please try again.',
        ];
    }

    Http::redirect('/admin/navigation');
});

$router->post('/admin/navigation/(\d+)/inline', function ($id)
{
    $id    = (int) $id;
    $field = isset($_POST['field']) ? trim((string) $_POST['field']) : '';
    $value = isset($_POST['value']) ? (string) $_POST['value'] : '';

    $allowed = ['label', 'url', 'icon', 'section'];
    if (!in_array($field, $allowed, true)) {
        Http::json(['status' => 'error', 'message' => 'Invalid field.'], 422);
        return;
    }

    $current = NavigationRepository::find($id);
    if (!$current) {
        Http::json(['status' => 'error', 'message' => 'Navigation link not found.'], 404);
        return;
    }

    $payload = [
        'label'   => $current['label'],
        'url'     => $current['url'],
        'icon'    => $current['icon'],
        'section' => $current['section'] ?? 'Main',
    ];

    $normalised = trim($value);

    if ($field === 'icon') {
        $payload['icon'] = $normalised !== '' ? $normalised : null;
    } elseif ($field === 'section') {
        $payload['section'] = $normalised !== '' ? $normalised : 'Main';
    } else {
        if ($normalised === '') {
            Http::json(['status' => 'error', 'message' => ucfirst($field) . ' is required.'], 422);
            return;
        }
        $payload[$field] = $normalised;
    }

    try {
        if (!NavigationRepository::update($id, $payload)) {
            Http::json(['status' => 'error', 'message' => 'Navigation link could not be updated.'], 500);
            return;
        }
    } catch (\InvalidArgumentException $e) {
        Http::json(['status' => 'error', 'message' => $e->getMessage()], 422);
        return;
    } catch (\Throwable $e) {
        Http::json(['status' => 'error', 'message' => 'Unable to update navigation link. Please try again.'], 500);
        return;
    }

    $responseValue = $field === 'icon' ? ($payload['icon'] ?? '') : $payload[$field];
    Http::json([
        'status' => 'ok',
        'value'  => $responseValue,
    ]);
});

$router->post('/admin/navigation/(\d+)/delete', function ($id)
{
    $id = (int) $id;
    try {
        if (NavigationRepository::delete($id)) {
            $_SESSION['navigation_flash'] = [
                'success' => 'Navigation link deleted.',
            ];
        } else {
            $_SESSION['navigation_flash'] = [
                'error' => 'Navigation link could not be deleted.',
            ];
        }
    } catch (\Throwable $e) {
        $_SESSION['navigation_flash'] = [
            'error' => 'Unable to delete navigation link. Please try again.',
        ];
    }

    Http::redirect('/admin/navigation');
});

$router->post('/admin/navigation/reorder', function ()
{
    $content = file_get_contents('php://input');
    $payload = json_decode($content, true);

    if (!is_array($payload) || !isset($payload['orders']) || !is_array($payload['orders'])) {
        Http::json(['status' => 'error', 'message' => 'Invalid payload.'], 400);
        return;
    }

    $orders = [];
    foreach ($payload['orders'] as $section => $ids) {
        if (!is_array($ids)) {
            continue;
        }
        $orders[$section] = array_values(
            array_filter(
                array_map('intval', $ids),
                static fn($id) => $id > 0
            )
        );
    }

    try {
        NavigationRepository::reorder($orders);
        Http::json(['status' => 'ok']);
    } catch (\Throwable $e) {
        Http::json([
            'status'  => 'error',
            'message' => $e->getMessage() ?: 'Unable to reorder navigation.',
        ], 500);
    }
});

$router->get('/admin/files', function () use ($fileManagerNormaliseRelative, $fileManagerSizeToBytes, $fileManagerRootLabel, $fileManagerRootMeta, $fileManagerDefaultRelativeRoot, $fileManagerProjectRoot)
{
    $initial = $fileManagerNormaliseRelative($_GET['path'] ?? '');

    $uploadLimit = ini_get('upload_max_filesize');
    $postLimit   = ini_get('post_max_size');
    $memoryLimit = ini_get('memory_limit');

    $limits = array_filter([
        $fileManagerSizeToBytes($uploadLimit !== false ? $uploadLimit : null),
        $fileManagerSizeToBytes($postLimit !== false ? $postLimit : null),
        $fileManagerSizeToBytes($memoryLimit !== false ? $memoryLimit : null),
    ], static fn($value) => $value !== null && $value > 0);

    $maxUploadBytes = $limits ? min($limits) : null;

    echo TwigHelper::render('admin/files.twig', [
        'title'            => 'File Manager',
        'initial_path'     => $initial,
        'max_upload_bytes' => $maxUploadBytes,
        'max_upload_human' => $maxUploadBytes !== null ? Format::bytes($maxUploadBytes) : null,
        'file_manager'     => [
            'root_label'        => $fileManagerRootLabel,
            'root_config'       => $fileManagerRootMeta['config'],
            'root_absolute'     => $fileManagerRootMeta['absolute'],
            'root_relative'     => $fileManagerRootMeta['relative'],
            'default_root'      => $fileManagerDefaultRelativeRoot,
            'project_root'      => $fileManagerProjectRoot,
            'settings_endpoint' => '/admin/files/settings',
        ],
    ]);
});

$router->get('/admin/files/list', function () use ($fileManagerResolvePath, $fileManagerPathInRoot, $fileManagerIconClass, $fileManagerRootLabel)
{
    [$absolute, $relative] = $fileManagerResolvePath($_GET['path'] ?? '');

    $targetDir = is_dir($absolute) ? realpath($absolute) : false;
    if ($targetDir === false) {
        Http::json(['status' => 'error', 'message' => 'Directory not found.'], 404);
    }

    if (!$fileManagerPathInRoot($targetDir)) {
        Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
    }

    $entries = scandir($targetDir);
    if ($entries === false) {
        Http::json(['status' => 'error', 'message' => 'Unable to read directory.'], 500);
    }

    $directories = [];
    $files       = [];

    foreach ($entries as $entry) {
        if ($entry === '.' || $entry === '..') {
            continue;
        }

        $entryPath     = $targetDir . DIRECTORY_SEPARATOR . $entry;
        $entryRelative = $relative === '' ? $entry : $relative . '/' . $entry;
        $modified      = @filemtime($entryPath) ?: null;
        $modifiedIso   = $modified ? date(DATE_ATOM, $modified) : null;
        $modifiedHuman = $modified ? date('Y-m-d H:i', $modified) : null;

        if (is_dir($entryPath)) {
            $children  = @scandir($entryPath);
            $itemCount = $children === false ? null : max(count($children) - 2, 0);

            $directories[] = [
                'name'           => $entry,
                'path'           => $entryRelative,
                'items'          => $itemCount,
                'modified'       => $modifiedIso,
                'modified_human' => $modifiedHuman,
                'writable'       => is_writable($entryPath),
                'icon'           => 'fa-folder',
            ];
            continue;
        }

        if (!is_file($entryPath)) {
            continue;
        }

        $size       = @filesize($entryPath);
        $size       = $size !== false ? (int) $size : 0;
        $extension  = Files::extension($entryPath);
        $mimeType   = Files::mimeType($entryPath) ?: 'application/octet-stream';
        $isImage    = str_starts_with($mimeType, 'image/');
        $isVideo    = str_starts_with($mimeType, 'video/');
        $isPdf      = $mimeType === 'application/pdf';
        $icon       = $fileManagerIconClass($extension, $mimeType);
        $previewUrl = null;

        if ($isImage || $isVideo || $isPdf) {
            $previewUrl = '/admin/files/preview?path=' . rawurlencode($entryRelative);
            if (is_int($modified) && $modified > 0) {
                $previewUrl .= (str_contains($previewUrl, '?') ? '&' : '?') . 'v=' . $modified;
            }
        }

        $files[] = [
            'name'           => $entry,
            'path'           => $entryRelative,
            'size'           => $size,
            'size_human'     => Format::bytes($size),
            'extension'      => $extension,
            'mime'           => $mimeType,
            'modified'       => $modifiedIso,
            'modified_human' => $modifiedHuman,
            'writable'       => is_writable($entryPath),
            'icon'           => $icon,
            'preview_url'    => $previewUrl,
            'is_image'       => $isImage,
            'is_video'       => $isVideo,
            'is_pdf'         => $isPdf,
        ];
    }

    usort($directories, static fn($a, $b) => strcasecmp($a['name'], $b['name']));
    usort($files, static fn($a, $b) => strcasecmp($a['name'], $b['name']));

    $breadcrumbs = [
        ['label' => $fileManagerRootLabel, 'path' => ''],
    ];

    if ($relative !== '') {
        $segments    = explode('/', $relative);
        $accumulated = '';
        foreach ($segments as $segment) {
            $accumulated .= ($accumulated === '' ? '' : '/') . $segment;
            $breadcrumbs[] = [
                'label' => $segment,
                'path'  => $accumulated,
            ];
        }
    }

    $parent = null;
    if ($relative !== '') {
        $parts = explode('/', $relative);
        array_pop($parts);
        $parent = implode('/', $parts);
        if ($parent === '') {
            $parent = null;
        }
    }

    Http::json([
        'status'      => 'ok',
        'path'        => $relative,
        'parent'      => $parent,
        'breadcrumbs' => $breadcrumbs,
        'directories' => $directories,
        'files'       => $files,
        'writable'    => is_writable($targetDir),
        'name'        => $relative === '' ? $fileManagerRootLabel : basename($relative),
    ]);
});

$router->post('/admin/files/create-directory', function () use ($fileManagerResolvePath, $fileManagerPathInRoot, $fileManagerValidateEntryName)
{
    $name = (string) ($_POST['name'] ?? '');

    if (!$fileManagerValidateEntryName($name)) {
        Http::json(['status' => 'error', 'message' => 'Please provide a valid folder name.'], 422);
    }

    [$parentAbsolute, $parentRelative] = $fileManagerResolvePath($_POST['path'] ?? '');
    $targetDir                         = is_dir($parentAbsolute) ? realpath($parentAbsolute) : false;

    if ($targetDir === false) {
        Http::json(['status' => 'error', 'message' => 'Destination folder not found.'], 404);
    }

    if (!$fileManagerPathInRoot($targetDir)) {
        Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
    }

    $newPath = $targetDir . DIRECTORY_SEPARATOR . $name;
    if (!$fileManagerPathInRoot($newPath)) {
        Http::json(['status' => 'error', 'message' => 'Invalid folder target.'], 403);
    }

    if (file_exists($newPath)) {
        Http::json(['status' => 'error', 'message' => 'A file or folder with that name already exists.'], 409);
    }

    if (!Files::createDirectory($newPath)) {
        Http::json(['status' => 'error', 'message' => 'Unable to create folder.'], 500);
    }

    $relative = $parentRelative === '' ? $name : $parentRelative . '/' . $name;

    Http::json([
        'status' => 'ok',
        'path'   => $relative,
        'name'   => $name,
    ]);
});

$router->post('/admin/files/create-file', function () use ($fileManagerResolvePath, $fileManagerPathInRoot, $fileManagerValidateEntryName)
{
    $name = (string) ($_POST['name'] ?? '');

    if (!$fileManagerValidateEntryName($name)) {
        Http::json(['status' => 'error', 'message' => 'Please provide a valid file name.'], 422);
    }

    [$parentAbsolute, $parentRelative] = $fileManagerResolvePath($_POST['path'] ?? '');
    $targetDir                         = is_dir($parentAbsolute) ? realpath($parentAbsolute) : false;

    if ($targetDir === false) {
        Http::json(['status' => 'error', 'message' => 'Destination folder not found.'], 404);
    }

    if (!$fileManagerPathInRoot($targetDir)) {
        Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
    }

    if (!is_writable($targetDir)) {
        Http::json(['status' => 'error', 'message' => 'Destination is not writable.'], 403);
    }

    $newFilePath = $targetDir . DIRECTORY_SEPARATOR . $name;

    if (!$fileManagerPathInRoot($newFilePath)) {
        Http::json(['status' => 'error', 'message' => 'Invalid file target.'], 403);
    }

    if (file_exists($newFilePath)) {
        Http::json(['status' => 'error', 'message' => 'A file or folder with that name already exists.'], 409);
    }

    $writeResult = Files::write($newFilePath, '');
    if ($writeResult === false) {
        Http::json(['status' => 'error', 'message' => 'Unable to create file.'], 500);
    }

    $relative = $parentRelative === '' ? $name : $parentRelative . '/' . $name;

    Http::json([
        'status'  => 'ok',
        'path'    => $relative,
        'name'    => $name,
        'message' => 'File created.',
    ]);
});

$router->post('/admin/files/rename', function () use ($fileManagerResolvePath, $fileManagerPathInRoot, $fileManagerValidateEntryName)
{
    $pathParam = (string) ($_POST['path'] ?? '');
    $newName   = (string) ($_POST['name'] ?? '');

    if ($pathParam === '') {
        Http::json(['status' => 'error', 'message' => 'Item path is required.'], 422);
    }

    if (!$fileManagerValidateEntryName($newName)) {
        Http::json(['status' => 'error', 'message' => 'Please provide a valid name.'], 422);
    }

    [$absolute, $relative] = $fileManagerResolvePath($pathParam);
    $currentPath           = file_exists($absolute) ? realpath($absolute) : false;

    if ($currentPath === false) {
        Http::json(['status' => 'error', 'message' => 'Item not found.'], 404);
    }

    if (!$fileManagerPathInRoot($currentPath)) {
        Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
    }

    if ($relative === '') {
        Http::json(['status' => 'error', 'message' => 'The root folder cannot be renamed.'], 400);
    }

    $parentDir = dirname($currentPath);
    if (!$fileManagerPathInRoot($parentDir)) {
        Http::json(['status' => 'error', 'message' => 'Invalid target path.'], 403);
    }

    $target = $parentDir . DIRECTORY_SEPARATOR . $newName;
    if (!$fileManagerPathInRoot($target)) {
        Http::json(['status' => 'error', 'message' => 'Invalid target path.'], 403);
    }

    if (file_exists($target)) {
        Http::json(['status' => 'error', 'message' => 'A file or folder with that name already exists.'], 409);
    }

    if (!Files::move($currentPath, $target)) {
        Http::json(['status' => 'error', 'message' => 'Unable to rename item.'], 500);
    }

    $relativeParts = explode('/', $relative);
    array_pop($relativeParts);
    $parentRelative = implode('/', array_filter($relativeParts, static fn($part) => $part !== ''));
    $newRelative    = $parentRelative === '' ? $newName : $parentRelative . '/' . $newName;

    Http::json([
        'status' => 'ok',
        'path'   => $newRelative,
        'name'   => $newName,
    ]);
});

$router->post('/admin/files/delete', function () use ($fileManagerResolvePath, $fileManagerPathInRoot)
{
    $pathParam = (string) ($_POST['path'] ?? '');

    if ($pathParam === '') {
        Http::json(['status' => 'error', 'message' => 'Item path is required.'], 422);
    }

    [$absolute, $relative] = $fileManagerResolvePath($pathParam);
    $targetPath            = file_exists($absolute) ? realpath($absolute) : false;

    if ($targetPath === false) {
        Http::json(['status' => 'error', 'message' => 'Item not found.'], 404);
    }

    if (!$fileManagerPathInRoot($targetPath)) {
        Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
    }

    if ($relative === '') {
        Http::json(['status' => 'error', 'message' => 'The root folder cannot be deleted.'], 400);
    }

    $deleted = is_dir($targetPath) ? Files::deleteDirectory($targetPath) : Files::delete($targetPath);

    if (!$deleted) {
        Http::json(['status' => 'error', 'message' => 'Unable to delete item.'], 500);
    }

    Http::json(['status' => 'ok']);
});

$router->post('/admin/files/delete-multiple', function () use ($fileManagerResolvePath, $fileManagerNormaliseRelative, $fileManagerPathInRoot)
{
    $content = file_get_contents('php://input');
    $payload = is_string($content) && $content !== '' ? json_decode($content, true) : null;

    if (!is_array($payload)) {
        Http::json(['status' => 'error', 'message' => 'Invalid request payload.'], 400);
    }

    $pathsInput = $payload['paths'] ?? [];

    if (!is_array($pathsInput) || !$pathsInput) {
        Http::json(['status' => 'error', 'message' => 'No items selected.'], 422);
    }

    $normalized = [];
    foreach ($pathsInput as $entry) {
        if (!is_string($entry)) {
            continue;
        }
        $path = $fileManagerNormaliseRelative($entry);
        if ($path !== '') {
            $normalized[$path] = $path;
        }
    }

    if (!$normalized) {
        Http::json(['status' => 'error', 'message' => 'No valid items provided.'], 422);
    }

    $results      = [];
    $deletedCount = 0;

    foreach ($normalized as $relativePath) {
        [$absolute, $normalizedRelative] = $fileManagerResolvePath($relativePath);
        $resolvedPath                    = file_exists($absolute) ? realpath($absolute) : false;
        $label                           = $normalizedRelative !== '' ? basename($normalizedRelative) : basename($relativePath);

        if ($resolvedPath === false) {
            $results[] = [
                'path'    => $relativePath,
                'name'    => $label,
                'status'  => 'error',
                'message' => 'Item not found.',
            ];
            continue;
        }

        if (!$fileManagerPathInRoot($resolvedPath)) {
            $results[] = [
                'path'    => $relativePath,
                'name'    => $label,
                'status'  => 'error',
                'message' => 'Access denied.',
            ];
            continue;
        }

        if ($normalizedRelative === '') {
            $results[] = [
                'path'    => $relativePath,
                'name'    => $label,
                'status'  => 'error',
                'message' => 'The root folder cannot be deleted.',
            ];
            continue;
        }

        $parent = dirname($resolvedPath);
        if ($parent === '' || !$fileManagerPathInRoot($parent) || !is_writable($parent)) {
            $results[] = [
                'path'    => $relativePath,
                'name'    => $label,
                'status'  => 'error',
                'message' => 'Destination is read-only.',
            ];
            continue;
        }

        $deleted = is_dir($resolvedPath)
            ? Files::deleteDirectory($resolvedPath)
            : Files::delete($resolvedPath);

        if ($deleted) {
            $deletedCount += 1;
            $results[]    = [
                'path'   => $normalizedRelative,
                'name'   => $label,
                'status' => 'ok',
            ];
        } else {
            $results[] = [
                'path'    => $relativePath,
                'name'    => $label,
                'status'  => 'error',
                'message' => 'Unable to delete item.',
            ];
        }
    }

    $total = count($normalized);
    if ($deletedCount === 0) {
        $status  = 'error';
        $message = 'Unable to delete selected items.';
    } elseif ($deletedCount < $total) {
        $status  = 'partial';
        $message = 'Some items could not be deleted.';
    } else {
        $status  = 'ok';
        $message = $deletedCount === 1 ? 'Deleted 1 item.' : 'Deleted ' . $deletedCount . ' items.';
    }

    Http::json([
        'status'  => $status,
        'message' => $message,
        'deleted' => $deletedCount,
        'results' => array_values($results),
    ]);
});

$router->post('/admin/files/transfer', function () use ($fileManagerResolvePath, $fileManagerNormaliseRelative, $fileManagerPathInRoot, $fileManagerCopyRecursive, $fileManagerPathIsDescendant)
{
    $content = file_get_contents('php://input');
    $payload = is_string($content) && $content !== '' ? json_decode($content, true) : null;

    if (!is_array($payload)) {
        Http::json(['status' => 'error', 'message' => 'Invalid request payload.'], 400);
    }

    $modeRaw = isset($payload['mode']) ? strtolower((string) $payload['mode']) : '';
    if (!in_array($modeRaw, ['copy', 'move'], true)) {
        Http::json(['status' => 'error', 'message' => 'Invalid transfer mode.'], 422);
    }

    $pathsInput = $payload['paths'] ?? [];
    if (!is_array($pathsInput) || !$pathsInput) {
        Http::json(['status' => 'error', 'message' => 'No items selected.'], 422);
    }

    $normalisedSet = [];
    foreach ($pathsInput as $entry) {
        if (!is_string($entry)) {
            continue;
        }
        $normalised = $fileManagerNormaliseRelative($entry);
        if ($normalised !== '') {
            $normalisedSet[$normalised] = $normalised;
        }
    }

    if (!$normalisedSet) {
        Http::json(['status' => 'error', 'message' => 'No valid items provided.'], 422);
    }

    [$targetAbsolute, $targetRelative] = $fileManagerResolvePath(isset($payload['target']) ? (string) $payload['target'] : '');
    $targetDirectory                   = is_dir($targetAbsolute) ? realpath($targetAbsolute) : false;

    if ($targetDirectory === false) {
        Http::json(['status' => 'error', 'message' => 'Destination folder not found.'], 404);
    }

    if (!$fileManagerPathInRoot($targetDirectory)) {
        Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
    }

    if (!is_dir($targetDirectory) || !is_writable($targetDirectory)) {
        Http::json(['status' => 'error', 'message' => 'Destination folder is not writable.'], 403);
    }

    $paths        = array_values($normalisedSet);
    $results      = [];
    $successCount = 0;

    $generateCopyTarget = static function (string $directory, string $originalName) use ($fileManagerPathInRoot)
    {
        $baseDirectory = rtrim($directory, DIRECTORY_SEPARATOR);
        if ($baseDirectory === '') {
            $baseDirectory = DIRECTORY_SEPARATOR;
        }

        $info      = pathinfo($originalName);
        $baseName  = $info['filename'] ?? $originalName;
        $extension = '';

        if (isset($info['extension']) && $info['extension'] !== '') {
            $extension = '.' . $info['extension'];
        } elseif (!isset($info['filename'])) {
            $baseName = $originalName;
        }

        // Handle filenames beginning with a dot (e.g. .env)
        if ($originalName !== '' && $originalName[0] === '.' && ($info['filename'] ?? '') === '') {
            $baseName  = $originalName;
            $extension = '';
        }

        // Normalise multiple dots (e.g. archive.tar.gz)
        if (($info['filename'] ?? '') !== '' && ($info['extension'] ?? '') !== '') {
            $lastDot = strrpos($originalName, '.');
            if ($lastDot !== false) {
                $baseName  = substr($originalName, 0, $lastDot);
                $extension = substr($originalName, $lastDot);
            }
        }

        $attempt = 0;

        while (true) {
            $suffix        = $attempt === 0 ? '_copy' : '_copy' . ($attempt + 1);
            $candidateName = $baseName . $suffix . $extension;
            $candidatePath = $baseDirectory . DIRECTORY_SEPARATOR . $candidateName;

            if (!$fileManagerPathInRoot($candidatePath)) {
                return [null, null];
            }

            if (!file_exists($candidatePath)) {
                return [$candidateName, $candidatePath];
            }

            $attempt++;

            if ($attempt > 200) {
                // Prevent potential infinite loops in extreme cases
                return [null, null];
            }
        }
    };

    foreach ($paths as $relativePath) {
        [$sourceAbsolute, $sourceRelative] = $fileManagerResolvePath($relativePath);
        $resolvedSource                    = file_exists($sourceAbsolute) ? realpath($sourceAbsolute) : false;

        if ($resolvedSource === false) {
            $results[] = [
                'path'    => $sourceRelative,
                'status'  => 'error',
                'message' => 'Item not found.',
            ];
            continue;
        }

        if (!$fileManagerPathInRoot($resolvedSource)) {
            $results[] = [
                'path'    => $sourceRelative,
                'status'  => 'error',
                'message' => 'Access denied.',
            ];
            continue;
        }

        if ($sourceRelative === '') {
            $results[] = [
                'path'    => $sourceRelative,
                'status'  => 'error',
                'message' => 'The root folder cannot be transferred.',
            ];
            continue;
        }

        $isDirectory = is_dir($resolvedSource);
        $isFile      = is_file($resolvedSource);

        if (!$isDirectory && !$isFile) {
            $results[] = [
                'path'    => $sourceRelative,
                'status'  => 'error',
                'message' => 'Unsupported item type.',
            ];
            continue;
        }

        if (!is_readable($resolvedSource)) {
            $results[] = [
                'path'    => $sourceRelative,
                'status'  => 'error',
                'message' => 'Item is not readable.',
            ];
            continue;
        }

        $itemName        = basename($resolvedSource);
        $destinationPath = $targetDirectory . DIRECTORY_SEPARATOR . $itemName;

        if (!$fileManagerPathInRoot($destinationPath)) {
            $results[] = [
                'path'    => $sourceRelative,
                'status'  => 'error',
                'message' => 'Invalid destination path.',
            ];
            continue;
        }

        if ($isDirectory && $fileManagerPathIsDescendant($resolvedSource, $targetDirectory, false)) {
            $results[] = [
                'path'    => $sourceRelative,
                'status'  => 'error',
                'message' => 'Cannot transfer a folder into itself.',
            ];
            continue;
        }

        if (file_exists($destinationPath)) {
            if ($modeRaw === 'copy') {
                [$copyName, $copyPath] = $generateCopyTarget($targetDirectory, $itemName);
                if ($copyName === null || $copyPath === null) {
                    $results[] = [
                        'path'    => $sourceRelative,
                        'status'  => 'error',
                        'message' => 'Unable to generate a unique name for the copy.',
                    ];
                    continue;
                }

                $itemName        = $copyName;
                $destinationPath = $copyPath;
            } else {
                $results[] = [
                    'path'    => $sourceRelative,
                    'status'  => 'error',
                    'message' => 'An item with the same name already exists in the destination.',
                ];
                continue;
            }
        }

        if ($modeRaw === 'move') {
            $parentDir = dirname($resolvedSource);
            if (!is_writable($parentDir)) {
                $results[] = [
                    'path'    => $sourceRelative,
                    'status'  => 'error',
                    'message' => 'Item cannot be moved because its parent folder is read-only.',
                ];
                continue;
            }

            if (!Files::move($resolvedSource, $destinationPath)) {
                $results[] = [
                    'path'    => $sourceRelative,
                    'status'  => 'error',
                    'message' => 'Unable to move item.',
                ];
                continue;
            }
        } else {
            if (!$fileManagerCopyRecursive($resolvedSource, $destinationPath)) {
                $results[] = [
                    'path'    => $sourceRelative,
                    'status'  => 'error',
                    'message' => 'Unable to copy item.',
                ];
                continue;
            }
        }

        $successCount++;
        $results[] = [
            'path'   => $sourceRelative,
            'name'   => $itemName,
            'status' => 'ok',
            'target' => trim($targetRelative === '' ? $itemName : $targetRelative . '/' . $itemName, '/'),
        ];
    }

    if ($successCount === 0) {
        Http::json([
            'status'  => 'error',
            'message' => $modeRaw === 'copy' ? 'Unable to copy the selected items.' : 'Unable to move the selected items.',
            'results' => $results,
            'mode'    => $modeRaw,
            'target'  => $targetRelative,
        ], 400);
    }

    $failedCount = count($results) - $successCount;
    $status      = $failedCount > 0 ? 'partial' : 'ok';

    $errors = array_values(array_filter($results, static fn($entry) => ($entry['status'] ?? '') !== 'ok'));

    $response = [
        'status'  => $status,
        'results' => $results,
        'errors'  => $errors,
        'mode'    => $modeRaw,
        'target'  => $targetRelative,
    ];

    if ($status !== 'ok') {
        $messageBase = $modeRaw === 'copy' ? 'Copied ' : 'Moved ';
        $message     = $messageBase . $successCount . ' ' . ($successCount === 1 ? 'item' : 'items') . '.';

        if ($failedCount > 0) {
            $message .= ' ' . $failedCount . ' item' . ($failedCount === 1 ? '' : 's') . ' could not be processed.';
        }

        $response['message'] = $message;
    }

    Http::json($response, $status === 'ok' ? 200 : 207);
});

$router->post('/admin/files/compress', function () use ($fileManagerResolvePath, $fileManagerNormaliseRelative, $fileManagerPathInRoot, $fileManagerAddToArchive)
{
    if (!class_exists('ZipArchive')) {
        Http::json(['status' => 'error', 'message' => 'ZIP support is not available on this server.'], 500);
    }

    $content = file_get_contents('php://input');
    $payload = is_string($content) && $content !== '' ? json_decode($content, true) : null;

    if (!is_array($payload)) {
        Http::json(['status' => 'error', 'message' => 'Invalid request payload.'], 400);
    }

    $pathsInput = $payload['paths'] ?? [];
    if (!is_array($pathsInput) || !$pathsInput) {
        Http::json(['status' => 'error', 'message' => 'No items selected.'], 422);
    }

    $normalisedSet = [];
    foreach ($pathsInput as $entry) {
        if (!is_string($entry)) {
            continue;
        }

        $normalised = $fileManagerNormaliseRelative($entry);
        if ($normalised !== '') {
            $normalisedSet[$normalised] = $normalised;
        }
    }

    if (!$normalisedSet) {
        Http::json(['status' => 'error', 'message' => 'No valid items provided.'], 422);
    }

    $items          = [];
    $parentAbsolute = null;
    $parentRelative = null;

    $resolveParentRelative = static function (string $relative): string
    {
        $segments = explode('/', $relative);
        array_pop($segments);
        $segments = array_filter($segments, static fn($segment) => $segment !== '');

        return implode('/', $segments);
    };

    foreach ($normalisedSet as $relativePath) {
        [$absolute, $normalizedRelative] = $fileManagerResolvePath($relativePath);
        $resolvedSource                  = file_exists($absolute) ? realpath($absolute) : false;

        if ($resolvedSource === false) {
            Http::json(['status' => 'error', 'message' => 'Item not found: ' . $relativePath], 404);
        }

        if (!$fileManagerPathInRoot($resolvedSource)) {
            Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
        }

        if (!is_readable($resolvedSource)) {
            Http::json(['status' => 'error', 'message' => 'Item is not readable: ' . basename($resolvedSource)], 403);
        }

        if ($normalizedRelative === '') {
            Http::json(['status' => 'error', 'message' => 'The root folder cannot be archived.'], 400);
        }

        $isDirectory = is_dir($resolvedSource);
        $isFile      = is_file($resolvedSource);

        if (!$isDirectory && !$isFile) {
            Http::json(['status' => 'error', 'message' => 'Unsupported item type.'], 400);
        }

        $currentParent         = dirname($resolvedSource);
        $currentParentRelative = $resolveParentRelative($normalizedRelative);

        if ($parentAbsolute === null) {
            $parentAbsolute = $currentParent;
            $parentRelative = $currentParentRelative;
        } elseif ($parentAbsolute !== $currentParent) {
            Http::json(['status' => 'error', 'message' => 'Selected items must be in the same folder.'], 422);
        }

        if (!is_dir($parentAbsolute) || !$fileManagerPathInRoot($parentAbsolute)) {
            Http::json(['status' => 'error', 'message' => 'Invalid archive destination.'], 403);
        }

        $items[] = [
            'absolute' => $resolvedSource,
            'relative' => $normalizedRelative,
            'name'     => basename($resolvedSource),
            'type'     => $isDirectory ? 'directory' : 'file',
        ];
    }

    if ($parentAbsolute === null) {
        Http::json(['status' => 'error', 'message' => 'Unable to determine archive destination.'], 500);
    }

    if (!is_writable($parentAbsolute)) {
        Http::json(['status' => 'error', 'message' => 'Destination folder is not writable.'], 403);
    }

    $determineBaseName = static function (array $entries): string
    {
        if (count($entries) === 1) {
            $name = $entries[0]['name'] ?? '';
            $name = is_string($name) ? trim($name) : '';
            if ($name !== '') {
                $dotPosition = strrpos($name, '.');
                if ($dotPosition !== false) {
                    $candidate = substr($name, 0, $dotPosition);
                    if ($candidate === '') {
                        $candidate = substr($name, 1);
                    }
                } else {
                    $candidate = $name;
                }

                $candidate = trim($candidate, ". ");
                if ($candidate !== '') {
                    return $candidate;
                }
            }
        }

        return 'archive';
    };

    $baseName = $determineBaseName($items);
    $baseName = trim($baseName);
    if ($baseName === '') {
        $baseName = 'archive';
    }
    $baseName = preg_replace('/[^A-Za-z0-9._-]/', '_', $baseName) ?: 'archive';

    $uniqueArchiveName = static function (string $directory, string $base): string
    {
        $candidate = $base . '.zip';
        $counter = 1;

        while (file_exists($directory . DIRECTORY_SEPARATOR . $candidate)) {
            $candidate = $base . ' (' . $counter . ').zip';
            $counter++;

            if ($counter > 100) {
                $candidate = $base . '-' . uniqid() . '.zip';
                break;
            }
        }

        return $candidate;
    };

    $archiveName = $uniqueArchiveName($parentAbsolute, $baseName);
    $archivePath = $parentAbsolute . DIRECTORY_SEPARATOR . $archiveName;

    if (!$fileManagerPathInRoot($archivePath)) {
        Http::json(['status' => 'error', 'message' => 'Invalid archive destination.'], 403);
    }

    $zip        = new \ZipArchive();
    $openResult = $zip->open($archivePath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
    if ($openResult !== true) {
        Http::json(['status' => 'error', 'message' => 'Unable to create archive file.'], 500);
    }

    foreach ($items as $item) {
        if (!$fileManagerAddToArchive($zip, $item['absolute'], $item['name'])) {
            $zip->close();
            @unlink($archivePath);
            Http::json(['status' => 'error', 'message' => 'Unable to add item to archive.'], 500);
        }
    }

    if ($zip->close() === false) {
        @unlink($archivePath);
        Http::json(['status' => 'error', 'message' => 'Unable to finalize archive.'], 500);
    }

    $archiveRelative = $parentRelative === '' ? $archiveName : $parentRelative . '/' . $archiveName;

    Http::json([
        'status'  => 'ok',
        'archive' => [
            'name' => $archiveName,
            'path' => $archiveRelative,
        ],
        'items'   => count($items),
        'message' => count($items) === 1
            ? 'Created archive ' . $archiveName . '.'
            : 'Created archive ' . $archiveName . ' from ' . count($items) . ' items.',
    ]);
});

$router->post('/admin/files/decompress', function () use ($fileManagerResolvePath, $fileManagerNormaliseRelative, $fileManagerPathInRoot)
{
    $content = file_get_contents('php://input');
    $payload = is_string($content) && $content !== '' ? json_decode($content, true) : null;

    if (!is_array($payload)) {
        Http::json(['status' => 'error', 'message' => 'Invalid request payload.'], 400);
    }

    $pathsInput = $payload['paths'] ?? [];
    if (!is_array($pathsInput) || !$pathsInput) {
        Http::json(['status' => 'error', 'message' => 'No items selected.'], 422);
    }

    $normalisedSet = [];
    foreach ($pathsInput as $entry) {
        if (!is_string($entry)) {
            continue;
        }

        $normalised = $fileManagerNormaliseRelative($entry);
        if ($normalised !== '') {
            $normalisedSet[$normalised] = $normalised;
        }
    }

    if (!$normalisedSet) {
        Http::json(['status' => 'error', 'message' => 'No valid items provided.'], 422);
    }

    $detectArchive = static function (string $filename): ?array
    {
        $basename = basename($filename);
        $lower = strtolower($basename);

        if (str_ends_with($lower, '.tar.gz')) {
            $base = substr($basename, 0, -7);
            if ($base === '' || $base === '.' || $base === '..') {
                $base = $basename;
            }
            return ['type' => 'tar.gz', 'base' => $base];
        }

        if (str_ends_with($lower, '.tgz')) {
            $base = substr($basename, 0, -4);
            if ($base === '' || $base === '.' || $base === '..') {
                $base = $basename;
            }
            return ['type' => 'tar.gz', 'base' => $base];
        }

        if (str_ends_with($lower, '.tar')) {
            $base = preg_replace('/\.tar$/i', '', $basename) ?: $basename;
            return ['type' => 'tar', 'base' => $base];
        }

        if (str_ends_with($lower, '.zip')) {
            $base = preg_replace('/\.zip$/i', '', $basename) ?: $basename;
            return ['type' => 'zip', 'base' => $base];
        }

        if (str_ends_with($lower, '.gz')) {
            $base = preg_replace('/\.gz$/i', '', $basename) ?: $basename;
            return ['type' => 'gz', 'base' => $base];
        }

        return null;
    };

    $sanitizeName = static function (string $name, string $fallback = 'extracted'): string
    {
        $clean = trim(str_replace("\0", '', $name));
        $clean = str_replace(['\\', '/'], '', $clean);
        if ($clean === '' || $clean === '.' || $clean === '..') {
            $clean = $fallback;
        }

        return $clean;
    };

    $uniqueDirectory = static function (string $directory, string $name): string
    {
        $base      = $name;
        $candidate = $base;
        $counter = 1;

        while (file_exists($directory . DIRECTORY_SEPARATOR . $candidate)) {
            $candidate = $base . ' (' . $counter . ')';
            $counter++;

            if ($counter > 100) {
                $candidate = $base . '-' . uniqid();
                break;
            }
        }

        return $candidate;
    };

    $uniqueFile = static function (string $directory, string $name): string
    {
        $info      = pathinfo($name);
        $base      = $info['filename'] ?? '';
        $extension = isset($info['extension']) && $info['extension'] !== '' ? '.' . $info['extension'] : '';

        if ($base === '' || $base === '.' || $base === '..') {
            $base = 'file';
        }

        $candidate = $base . $extension;
        $counter = 1;

        while (file_exists($directory . DIRECTORY_SEPARATOR . $candidate)) {
            $candidate = $base . ' (' . $counter . ')' . $extension;
            $counter++;

            if ($counter > 100) {
                $candidate = $base . '-' . uniqid();
                if ($extension !== '') {
                    $candidate .= $extension;
                }
                break;
            }
        }

        return $candidate;
    };

    $resolveParentRelative = static function (string $relative): string
    {
        $segments = explode('/', $relative);
        array_pop($segments);
        $segments = array_filter($segments, static fn($segment) => $segment !== '');

        return implode('/', $segments);
    };

    $results      = [];
    $successCount = 0;

    foreach ($normalisedSet as $relativePath) {
        [$absolute, $normalizedRelative] = $fileManagerResolvePath($relativePath);
        $resolvedSource                  = file_exists($absolute) ? realpath($absolute) : false;

        if ($resolvedSource === false) {
            $results[] = [
                'path'    => $relativePath,
                'status'  => 'error',
                'message' => 'Item not found.',
            ];
            continue;
        }

        if (!$fileManagerPathInRoot($resolvedSource)) {
            $results[] = [
                'path'    => $normalizedRelative,
                'status'  => 'error',
                'message' => 'Access denied.',
            ];
            continue;
        }

        if (!is_file($resolvedSource)) {
            $results[] = [
                'path'    => $normalizedRelative,
                'status'  => 'error',
                'message' => 'Selected item is not a file.',
            ];
            continue;
        }

        if (!is_readable($resolvedSource)) {
            $results[] = [
                'path'    => $normalizedRelative,
                'status'  => 'error',
                'message' => 'Item is not readable.',
            ];
            continue;
        }

        $archiveInfo = $detectArchive($resolvedSource);
        if ($archiveInfo === null) {
            $results[] = [
                'path'    => $normalizedRelative,
                'status'  => 'error',
                'message' => 'Unsupported archive type.',
            ];
            continue;
        }

        $parentAbsolute = dirname($resolvedSource);
        $parentRelative = $resolveParentRelative($normalizedRelative);

        if (!is_dir($parentAbsolute) || !$fileManagerPathInRoot($parentAbsolute)) {
            $results[] = [
                'path'    => $normalizedRelative,
                'status'  => 'error',
                'message' => 'Invalid extraction destination.',
            ];
            continue;
        }

        if (!is_writable($parentAbsolute)) {
            $results[] = [
                'path'    => $normalizedRelative,
                'status'  => 'error',
                'message' => 'Destination folder is not writable.',
            ];
            continue;
        }

        $type     = $archiveInfo['type'];
        $baseName = $sanitizeName($archiveInfo['base'], 'extracted');

        if ($type === 'zip') {
            if (!class_exists('ZipArchive')) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'ZIP support is not available on this server.',
                ];
                continue;
            }

            $targetDirName  = $uniqueDirectory($parentAbsolute, $baseName);
            $targetAbsolute = $parentAbsolute . DIRECTORY_SEPARATOR . $targetDirName;

            if (!$fileManagerPathInRoot($targetAbsolute)) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Invalid extraction destination.',
                ];
                continue;
            }

            if (!Files::createDirectory($targetAbsolute)) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to create extraction folder.',
                ];
                continue;
            }

            $zip        = new \ZipArchive();
            $openResult = $zip->open($resolvedSource);

            if ($openResult !== true) {
                if (method_exists($zip, 'close')) {
                    $zip->close();
                }
                Files::deleteDirectory($targetAbsolute);
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to extract archive.',
                ];
                continue;
            }

            $extractResult = $zip->extractTo($targetAbsolute);
            $zip->close();

            if ($extractResult === false) {
                Files::deleteDirectory($targetAbsolute);
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to extract archive.',
                ];
                continue;
            }

            $targetRelative = $parentRelative === '' ? $targetDirName : $parentRelative . '/' . $targetDirName;

            $results[] = [
                'path'      => $normalizedRelative,
                'status'    => 'ok',
                'target'    => $targetRelative,
                'extracted' => 'directory',
                'message'   => 'Extracted to ' . $targetRelative . '.',
            ];
            $successCount++;
            continue;
        }

        if ($type === 'tar' || $type === 'tar.gz') {
            if (!class_exists('PharData')) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'TAR support is not available on this server.',
                ];
                continue;
            }

            $targetDirName  = $uniqueDirectory($parentAbsolute, $baseName);
            $targetAbsolute = $parentAbsolute . DIRECTORY_SEPARATOR . $targetDirName;

            if (!$fileManagerPathInRoot($targetAbsolute)) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Invalid extraction destination.',
                ];
                continue;
            }

            if (!Files::createDirectory($targetAbsolute)) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to create extraction folder.',
                ];
                continue;
            }

            $temporaryTar = null;

            try {
                if ($type === 'tar.gz') {
                    $lowerSource = strtolower($resolvedSource);
                    if (str_ends_with($lowerSource, '.tgz')) {
                        $temporaryTar = substr($resolvedSource, 0, -4) . '.tar';
                    } else {
                        $temporaryTar = preg_replace('/\.gz$/i', '', $resolvedSource);
                        if ($temporaryTar === $resolvedSource) {
                            $temporaryTar = $resolvedSource . '.tar';
                        }
                    }

                    if ($temporaryTar !== null && $temporaryTar !== $resolvedSource && file_exists($temporaryTar)) {
                        @unlink($temporaryTar);
                    }

                    $phar = new \PharData($resolvedSource);
                    $phar->decompress();
                    unset($phar);

                    $pharTar = new \PharData($temporaryTar);
                    $pharTar->extractTo($targetAbsolute, null, true);
                    unset($pharTar);

                    if ($temporaryTar !== null && file_exists($temporaryTar)) {
                        @unlink($temporaryTar);
                    }
                } else {
                    $phar = new \PharData($resolvedSource);
                    $phar->extractTo($targetAbsolute, null, true);
                }
            } catch (\Throwable $e) {
                if ($temporaryTar !== null && file_exists($temporaryTar)) {
                    @unlink($temporaryTar);
                }

                Files::deleteDirectory($targetAbsolute);

                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to extract archive: ' . $e->getMessage(),
                ];
                continue;
            }

            $targetRelative = $parentRelative === '' ? $targetDirName : $parentRelative . '/' . $targetDirName;

            $results[] = [
                'path'      => $normalizedRelative,
                'status'    => 'ok',
                'target'    => $targetRelative,
                'extracted' => 'directory',
                'message'   => 'Extracted to ' . $targetRelative . '.',
            ];
            $successCount++;
            continue;
        }

        if ($type === 'gz') {
            if (!function_exists('gzopen')) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'GZip support is not available on this server.',
                ];
                continue;
            }

            $targetFileName = $uniqueFile($parentAbsolute, $baseName);
            $targetAbsolute = $parentAbsolute . DIRECTORY_SEPARATOR . $targetFileName;

            if (!$fileManagerPathInRoot($targetAbsolute)) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Invalid extraction destination.',
                ];
                continue;
            }

            $input = @gzopen($resolvedSource, 'rb');
            if ($input === false) {
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to read archive.',
                ];
                continue;
            }

            $output = @fopen($targetAbsolute, 'wb');
            if ($output === false) {
                gzclose($input);
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to create extracted file.',
                ];
                continue;
            }

            $failed = false;

            while (!gzeof($input)) {
                $chunk = gzread($input, 8192);
                if ($chunk === false) {
                    $failed = true;
                    break;
                }

                if (fwrite($output, $chunk) === false) {
                    $failed = true;
                    break;
                }
            }

            gzclose($input);
            fclose($output);

            if ($failed) {
                @unlink($targetAbsolute);
                $results[] = [
                    'path'    => $normalizedRelative,
                    'status'  => 'error',
                    'message' => 'Unable to extract archive.',
                ];
                continue;
            }

            $targetRelative = $parentRelative === '' ? $targetFileName : $parentRelative . '/' . $targetFileName;

            $results[] = [
                'path'      => $normalizedRelative,
                'status'    => 'ok',
                'target'    => $targetRelative,
                'extracted' => 'file',
                'message'   => 'Extracted to ' . $targetRelative . '.',
            ];
            $successCount++;
            continue;
        }

        $results[] = [
            'path'    => $normalizedRelative,
            'status'  => 'error',
            'message' => 'Unsupported archive type.',
        ];
    }

    $total       = count($results);
    $failedCount = count(array_filter($results, static fn($entry) => ($entry['status'] ?? '') !== 'ok'));

    $status = 'ok';
    if ($failedCount === $total) {
        $status = 'error';
    } elseif ($failedCount > 0) {
        $status = 'partial';
    }

    $errors = array_values(array_filter($results, static fn($entry) => ($entry['status'] ?? '') !== 'ok'));

    $response = [
        'status'  => $status,
        'results' => $results,
        'errors'  => $errors,
    ];

    if ($status === 'ok') {
        $response['message'] = $total === 1
            ? 'Archive extracted successfully.'
            : 'Extracted ' . $total . ' archives successfully.';
    } elseif ($status === 'partial') {
        $successful          = $total - $failedCount;
        $response['message'] = 'Extracted ' . $successful . ' of ' . $total . ' item' . ($total === 1 ? '' : 's') . '.';
    } else {
        $response['message'] = $total === 1
            ? ($results[0]['message'] ?? 'Unable to extract the selected item.')
            : 'Unable to extract the selected items.';
    }

    $statusCode = match ($status) {
        'ok' => 200,
        'partial' => 207,
        default => 400,
    };

    Http::json($response, $statusCode);
});

$router->post('/admin/files/upload', function () use ($fileManagerResolvePath, $fileManagerPathInRoot)
{
    [$targetAbsolute, $targetRelative] = $fileManagerResolvePath($_POST['path'] ?? '');

    $destination = is_dir($targetAbsolute) ? realpath($targetAbsolute) : false;
    if ($destination === false) {
        if (!Files::createDirectory($targetAbsolute)) {
            Http::json(['status' => 'error', 'message' => 'Destination folder not found.'], 404);
        }
        $destination = realpath($targetAbsolute) ?: $targetAbsolute;
    }

    if (!$fileManagerPathInRoot($destination)) {
        Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
    }

    if (!is_dir($destination) || !is_writable($destination)) {
        Http::json(['status' => 'error', 'message' => 'Destination is not writable.'], 403);
    }

    if (empty($_FILES)) {
        Http::json(['status' => 'error', 'message' => 'No files uploaded.'], 422);
    }

    $filesField = $_FILES['files'] ?? ($_FILES['file'] ?? null);
    if ($filesField === null) {
        Http::json(['status' => 'error', 'message' => 'No files uploaded.'], 422);
    }

    $normaliseFiles = static function (array $field): array
    {
        if (!is_array($field['name'])) {
            return [
                [
                    'name'     => $field['name'] ?? '',
                    'type'     => $field['type'] ?? null,
                    'tmp_name' => $field['tmp_name'] ?? '',
                    'error'    => $field['error'] ?? UPLOAD_ERR_NO_FILE,
                    'size'     => $field['size'] ?? 0,
                ],
            ];
        }

        $normalised = [];
        $count = count($field['name']);
        for ($i = 0; $i < $count; $i++) {
            $normalised[] = [
                'name'     => $field['name'][$i] ?? '',
                'type'     => $field['type'][$i] ?? null,
                'tmp_name' => $field['tmp_name'][$i] ?? '',
                'error'    => $field['error'][$i] ?? UPLOAD_ERR_NO_FILE,
                'size'     => $field['size'][$i] ?? 0,
            ];
        }

        return $normalised;
    };

    $errorMessage = static function (int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE => 'The uploaded file exceeds the upload_max_filesize directive.',
            UPLOAD_ERR_FORM_SIZE => 'The uploaded file exceeds the MAX_FILE_SIZE directive.',
            UPLOAD_ERR_PARTIAL => 'The uploaded file was only partially uploaded.',
            UPLOAD_ERR_NO_FILE => 'No file was uploaded.',
            UPLOAD_ERR_NO_TMP_DIR => 'Missing a temporary folder.',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
            UPLOAD_ERR_EXTENSION => 'A PHP extension stopped the file upload.',
            default => 'Unknown upload error.',
        };
    };

    $uniqueName = static function (string $dir, string $name): string
    {
        $clean = trim($name);
        if ($clean === '') {
            $clean = 'upload';
        }

        $clean = basename(str_replace(['\\', '/'], DIRECTORY_SEPARATOR, $clean));

        $pathInfo  = pathinfo($clean);
        $base      = $pathInfo['filename'] ?? 'upload';
        $extension = isset($pathInfo['extension']) && $pathInfo['extension'] !== ''
            ? '.' . $pathInfo['extension']
            : '';

        $candidate = $base . $extension;
        $counter = 1;
        while (file_exists($dir . DIRECTORY_SEPARATOR . $candidate)) {
            $candidate = $base . ' (' . $counter . ')' . $extension;
            $counter++;
            if ($counter > 100) {
                $candidate = $base . '-' . uniqid();
                if ($extension) {
                    $candidate .= $extension;
                }
                break;
            }
        }

        return $candidate;
    };

    $files    = $normaliseFiles($filesField);
    $uploaded = [];
    $failed   = [];

    foreach ($files as $file) {
        $originalName = (string) ($file['name'] ?? '');
        $error        = isset($file['error']) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;

        if ($error !== UPLOAD_ERR_OK) {
            $failed[] = ['name' => $originalName, 'message' => $errorMessage($error)];
            continue;
        }

        $tmpName = (string) ($file['tmp_name'] ?? '');
        if ($tmpName === '' || !is_uploaded_file($tmpName)) {
            $failed[] = ['name' => $originalName, 'message' => 'Invalid uploaded file.'];
            continue;
        }

        $cleanName = trim(basename(str_replace(['\\', '/'], DIRECTORY_SEPARATOR, $originalName)));
        if ($cleanName === '' || $cleanName === '.' || $cleanName === '..') {
            $failed[] = ['name' => $originalName, 'message' => 'Invalid file name.'];
            continue;
        }

        $finalName  = $uniqueName($destination, $cleanName);
        $targetPath = $destination . DIRECTORY_SEPARATOR . $finalName;

        if (!$fileManagerPathInRoot($targetPath)) {
            $failed[] = ['name' => $originalName, 'message' => 'Invalid destination path.'];
            continue;
        }

        if (!move_uploaded_file($tmpName, $targetPath)) {
            $failed[] = ['name' => $originalName, 'message' => 'Unable to move uploaded file.'];
            continue;
        }

        $uploaded[] = [
            'original' => $originalName,
            'name'     => $finalName,
            'path'     => $targetRelative === '' ? $finalName : $targetRelative . '/' . $finalName,
        ];
    }

    $status     = $uploaded ? 'ok' : 'error';
    $httpStatus = $uploaded ? 200 : 400;

    Http::json([
        'status'   => $status,
        'uploaded' => $uploaded,
        'errors'   => $failed,
        'message'  => $uploaded ? 'Upload complete.' : 'Unable to upload files.',
    ], $httpStatus);
});

$fileManagerTextMimePrefixes    = ['text/'];
$fileManagerTextAdditionalMimes = [
    'application/json',
    'application/ld+json',
    'application/javascript',
    'application/x-javascript',
    'application/xml',
    'application/xhtml+xml',
    'application/x-httpd-php',
    'application/x-sh',
    'application/x-shellscript',
    'application/sql',
    'application/x-sql',
    'application/x-yaml',
    'application/yaml',
    'application/x-twig',
    'application/x-latex',
    'application/x-perl',
    'application/x-ruby',
    'application/x-python',
    'application/ecmascript',
    'application/prs.cww',
    'application/x-markdown',
    'application/x-php',
];

$fileManagerTextExtensions = [
    'php',
    'phtml',
    'php3',
    'php4',
    'php5',
    'php7',
    'phps',
    'html',
    'htm',
    'xhtml',
    'shtml',
    'css',
    'scss',
    'sass',
    'less',
    'js',
    'jsx',
    'mjs',
    'cjs',
    'ts',
    'tsx',
    'vue',
    'svelte',
    'json',
    'json5',
    'jsonc',
    'yaml',
    'yml',
    'toml',
    'ini',
    'cfg',
    'conf',
    'cnf',
    'env',
    'dotenv',
    'xml',
    'xsl',
    'xslt',
    'rss',
    'atom',
    'md',
    'markdown',
    'mdx',
    'txt',
    'log',
    'rst',
    'tex',
    'latex',
    'sql',
    'psql',
    'c',
    'cc',
    'cpp',
    'cxx',
    'ino',
    'h',
    'hh',
    'hpp',
    'hxx',
    'cs',
    'java',
    'kt',
    'kts',
    'swift',
    'm',
    'mm',
    'py',
    'pyw',
    'pyi',
    'rb',
    'ru',
    'gemspec',
    'pl',
    'pm',
    'lua',
    'go',
    'rs',
    'dart',
    'erl',
    'ex',
    'exs',
    'fs',
    'fsi',
    'fsx',
    'ml',
    'mli',
    'sh',
    'bash',
    'zsh',
    'fish',
    'ksh',
    'csh',
    'ps1',
    'psm1',
    'psd1',
    'bat',
    'cmd',
    'coffee',
    'tscn',
    'godot',
    'gd',
    'cfm',
    'cfml',
    'latte',
    'njk',
    'twig',
    'liquid',
    'hbs',
    'handlebars',
    'mustache',
    'marko',
    'astro',
    'properties',
    'prefs',
    'gitignore',
    'npmignore',
    'dockerignore',
    'editorconfig',
    'manifest',
    'lock',
    'readme',
    'changelog',
    'lst',
    'list',
];

$fileManagerTextAdditionalMimesLower = array_map('strtolower', $fileManagerTextAdditionalMimes);

$router->get('/admin/files/download', function () use ($fileManagerResolvePath, $fileManagerPathInRoot, $fileManagerNormaliseRelative, $fileManagerAddToArchive)
{
    $pathsParam      = $_GET['paths'] ?? null;
    $normalizedPaths = [];

    if (is_array($pathsParam)) {
        foreach ($pathsParam as $entry) {
            if (!is_string($entry)) {
                continue;
            }
            $normalized = $fileManagerNormaliseRelative($entry);
            if ($normalized !== '') {
                $normalizedPaths[$normalized] = $normalized;
            }
        }
    } elseif (is_string($pathsParam) && $pathsParam !== '') {
        $normalized = $fileManagerNormaliseRelative($pathsParam);
        if ($normalized !== '') {
            $normalizedPaths[$normalized] = $normalized;
        }
    }

    $pathParam = '';

    if ($pathsParam !== null) {
        if (!$normalizedPaths) {
            Http::json(['status' => 'error', 'message' => 'No valid items provided.'], 422);
        }

        if (count($normalizedPaths) > 1) {
            if (!class_exists('ZipArchive')) {
                Http::json(['status' => 'error', 'message' => 'ZIP support is not available on this server.'], 500);
            }

            $items = [];

            foreach ($normalizedPaths as $relativePath) {
                [$absolute, $normalizedRelative] = $fileManagerResolvePath($relativePath);
                $resolvedPath                    = file_exists($absolute) ? realpath($absolute) : false;

                if ($resolvedPath === false || !$fileManagerPathInRoot($resolvedPath)) {
                    Http::json(['status' => 'error', 'message' => 'Item not found.'], 404);
                }

                if (!is_readable($resolvedPath)) {
                    Http::json(['status' => 'error', 'message' => 'Access denied.'], 403);
                }

                if ($normalizedRelative === '') {
                    Http::json(['status' => 'error', 'message' => 'The root folder cannot be downloaded.'], 400);
                }

                $items[] = [
                    'absolute' => $resolvedPath,
                    'name'     => basename($resolvedPath),
                ];
            }

            if (!$items) {
                Http::json(['status' => 'error', 'message' => 'No valid items provided.'], 422);
            }

            $baseName    = count($items) === 1 ? ($items[0]['name'] ?? 'selection') : 'selection';
            $dotPosition = strrpos($baseName, '.');
            if ($dotPosition !== false) {
                $candidate = substr($baseName, 0, $dotPosition);
                if ($candidate !== '') {
                    $baseName = $candidate;
                }
            }
            $baseName = preg_replace('/[^A-Za-z0-9._-]/', '_', $baseName) ?: 'selection';

            try {
                $randomSuffix = bin2hex(random_bytes(3));
            } catch (\Throwable $e) {
                $randomSuffix = substr(uniqid('', true), -6);
            }

            $downloadFile = $baseName . '-' . date('Ymd-His') . '-' . $randomSuffix . '.zip';
            $zipPath      = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . $downloadFile;

            $zip        = new \ZipArchive();
            $openResult = $zip->open($zipPath, \ZipArchive::CREATE | \ZipArchive::OVERWRITE);
            if ($openResult !== true) {
                Http::json(['status' => 'error', 'message' => 'Unable to create archive.'], 500);
            }

            foreach ($items as $item) {
                $sourcePath = $item['absolute'];
                $entryName  = $item['name'] ?? basename($sourcePath);
                if (!$fileManagerAddToArchive($zip, $sourcePath, $entryName)) {
                    $zip->close();
                    @unlink($zipPath);
                    Http::json(['status' => 'error', 'message' => 'Unable to add item to archive.'], 500);
                }
            }

            if ($zip->close() === false) {
                @unlink($zipPath);
                Http::json(['status' => 'error', 'message' => 'Unable to finalize archive.'], 500);
            }

            register_shutdown_function(static function () use ($zipPath)
            {
                if (file_exists($zipPath)) {
                    @unlink($zipPath);
                }
            });

            if (Http::download($zipPath, 'application/zip') === false) {
                @unlink($zipPath);
                Http::json(['status' => 'error', 'message' => 'Archive not found.'], 404);
            }

            return;
        }

        $pathParam = array_values($normalizedPaths)[0];
    } else {
        $pathParam = (string) ($_GET['path'] ?? '');
    }

    if ($pathParam === '') {
        Http::json(['status' => 'error', 'message' => 'File path is required.'], 422);
    }

    [$absolute] = $fileManagerResolvePath($pathParam);
    $filePath   = is_file($absolute) ? realpath($absolute) : false;

    if ($filePath === false || !$fileManagerPathInRoot($filePath)) {
        Http::json(['status' => 'error', 'message' => 'File not found.'], 404);
    }

    $mime = Files::mimeType($filePath) ?: 'application/octet-stream';
    if (Http::download($filePath, $mime) === false) {
        Http::json(['status' => 'error', 'message' => 'File not found.'], 404);
    }
});

$router->get('/admin/files/content', function () use ($fileManagerResolvePath, $fileManagerPathInRoot, $fileManagerTextMimePrefixes, $fileManagerTextAdditionalMimes, $fileManagerTextExtensions, $fileManagerTextAdditionalMimesLower)
{
    $pathParam = (string) ($_GET['path'] ?? '');

    if ($pathParam === '') {
        Http::json(['status' => 'error', 'message' => 'File path is required.'], 422);
    }

    [$absolute, $relative] = $fileManagerResolvePath($pathParam);
    $filePath              = is_file($absolute) ? realpath($absolute) : false;

    if ($filePath === false || !$fileManagerPathInRoot($filePath)) {
        Http::json(['status' => 'error', 'message' => 'File not found.'], 404);
    }

    $mime      = Files::mimeType($filePath) ?: 'application/octet-stream';
    $extension = Files::extension($filePath);
    $size      = @filesize($filePath);
    $size      = $size !== false ? (int) $size : 0;

    $normalizedMime = strtolower($mime);
    $isTextMime     = false;
    foreach ($fileManagerTextMimePrefixes as $prefix) {
        if ($prefix !== '' && str_starts_with($normalizedMime, strtolower($prefix))) {
            $isTextMime = true;
            break;
        }
    }

    if (!$isTextMime && in_array($normalizedMime, $fileManagerTextAdditionalMimesLower, true)) {
        $isTextMime = true;
    }

    $isTextExtension = in_array(strtolower($extension), $fileManagerTextExtensions, true);

    if (!$isTextMime && !$isTextExtension) {
        Http::json(['status' => 'error', 'message' => 'This file type cannot be displayed as text.'], 415);
    }

    $maxPreviewBytes = 2 * 1024 * 1024; // 2 MiB
    if ($size > $maxPreviewBytes) {
        Http::json([
            'status'  => 'error',
            'message' => 'File is too large to display inline. Maximum preview size is ' . Format::bytes($maxPreviewBytes) . '.',
        ], 413);
    }

    $content = Files::read($filePath);
    if ($content === false) {
        Http::json(['status' => 'error', 'message' => 'Unable to read file contents.'], 500);
    }

    if (str_contains($content, "\0")) {
        Http::json(['status' => 'error', 'message' => 'Binary content cannot be displayed as text.'], 415);
    }

    $charset = 'utf-8';
    if (function_exists('mb_detect_encoding')) {
        $detected = mb_detect_encoding($content, ['UTF-8', 'ASCII', 'ISO-8859-1', 'ISO-8859-15', 'WINDOWS-1252'], true);
        if (is_string($detected) && $detected !== '') {
            $charset = strtolower($detected);
            if ($charset === 'ascii') {
                $charset = 'utf-8';
            }
        }
    }

    $encoded = base64_encode($content);

    $modified      = @filemtime($filePath) ?: null;
    $modifiedIso   = $modified ? date(DATE_ATOM, $modified) : null;
    $modifiedHuman = $modified ? date('Y-m-d H:i', $modified) : null;

    $downloadUrl = '/admin/files/download?path=' . rawurlencode($relative);

    Http::json([
        'status'         => 'ok',
        'path'           => $relative,
        'name'           => basename($filePath),
        'mime'           => $mime,
        'extension'      => $extension,
        'size'           => $size,
        'size_human'     => Format::bytes($size),
        'modified'       => $modifiedIso,
        'modified_human' => $modifiedHuman,
        'encoding'       => 'base64',
        'charset'        => $charset,
        'content'        => $encoded,
        'download_url'   => $downloadUrl,
    ]);
});

$router->post('/admin/files/update-content', function () use ($fileManagerResolvePath, $fileManagerPathInRoot, $fileManagerTextMimePrefixes, $fileManagerTextAdditionalMimes, $fileManagerTextExtensions, $fileManagerTextAdditionalMimesLower)
{
    $pathParam = (string) ($_POST['path'] ?? '');

    if ($pathParam === '') {
        Http::json(['status' => 'error', 'message' => 'File path is required.'], 422);
    }

    [$absolute, $relative] = $fileManagerResolvePath($pathParam);
    $filePath              = is_file($absolute) ? realpath($absolute) : false;

    if ($filePath === false || !$fileManagerPathInRoot($filePath)) {
        Http::json(['status' => 'error', 'message' => 'File not found.'], 404);
    }

    if (!is_writable($filePath)) {
        Http::json(['status' => 'error', 'message' => 'File is not writable.'], 403);
    }

    $mime           = Files::mimeType($filePath) ?: 'application/octet-stream';
    $extension      = Files::extension($filePath);
    $normalizedMime = strtolower($mime);

    $isTextMime = false;
    foreach ($fileManagerTextMimePrefixes as $prefix) {
        if ($prefix !== '' && str_starts_with($normalizedMime, strtolower($prefix))) {
            $isTextMime = true;
            break;
        }
    }

    if (!$isTextMime && in_array($normalizedMime, $fileManagerTextAdditionalMimesLower, true)) {
        $isTextMime = true;
    }

    $isTextExtension = in_array(strtolower($extension), $fileManagerTextExtensions, true);

    if (!$isTextMime && !$isTextExtension) {
        Http::json(['status' => 'error', 'message' => 'Editing is unavailable for this file type.'], 415);
    }

    $encodedContent = (string) ($_POST['content'] ?? '');
    $charset        = trim((string) ($_POST['encoding'] ?? 'utf-8'));

    $decoded = $encodedContent === '' ? '' : base64_decode($encodedContent, true);
    if ($decoded === false) {
        Http::json(['status' => 'error', 'message' => 'Invalid content payload.'], 422);
    }

    if ($charset !== '' && strtolower($charset) !== 'utf-8' && function_exists('mb_convert_encoding')) {
        $converted = @mb_convert_encoding($decoded, 'UTF-8', $charset);
        if ($converted !== false) {
            $decoded = $converted;
            $charset = 'utf-8';
        }
    }

    if (Files::write($filePath, $decoded) === false) {
        Http::json(['status' => 'error', 'message' => 'Unable to write file.'], 500);
    }

    clearstatcache(true, $filePath);

    $size          = @filesize($filePath);
    $size          = $size !== false ? (int) $size : 0;
    $modified      = @filemtime($filePath) ?: null;
    $modifiedIso   = $modified ? date(DATE_ATOM, $modified) : null;
    $modifiedHuman = $modified ? date('Y-m-d H:i', $modified) : null;

    Http::json([
        'status'         => 'ok',
        'path'           => $relative,
        'size'           => $size,
        'size_human'     => Format::bytes($size),
        'modified'       => $modifiedIso,
        'modified_human' => $modifiedHuman,
        'mime'           => $mime,
        'extension'      => $extension,
        'encoding'       => $charset !== '' ? strtolower($charset) : 'utf-8',
    ]);
});

$router->get('/admin/files/preview', function () use ($fileManagerResolvePath, $fileManagerPathInRoot)
{
    $pathParam = (string) ($_GET['path'] ?? '');

    if ($pathParam === '') {
        Http::json(['status' => 'error', 'message' => 'File path is required.'], 422);
    }

    [$absolute] = $fileManagerResolvePath($pathParam);
    $filePath   = is_file($absolute) ? realpath($absolute) : false;

    if ($filePath === false || !$fileManagerPathInRoot($filePath)) {
        Http::json(['status' => 'error', 'message' => 'File not found.'], 404);
    }

    $mime          = Files::mimeType($filePath) ?: 'application/octet-stream';
    $isPreviewable = str_starts_with($mime, 'image/')
        || str_starts_with($mime, 'video/')
        || $mime === 'application/pdf';

    if (!$isPreviewable) {
        Http::json(['status' => 'error', 'message' => 'Preview unavailable for this file type.'], 415);
    }

    $length        = @filesize($filePath);
    $rangeHeader   = isset($_SERVER['HTTP_RANGE']) ? (string) $_SERVER['HTTP_RANGE'] : '';
    $supportsRange = $length !== false && $length > 0;
    $start         = 0;
    $end           = $supportsRange ? $length - 1 : 0;
    $status        = 200;

    if ($supportsRange && $rangeHeader !== '' && preg_match('/bytes=([0-9]*)-([0-9]*)/i', $rangeHeader, $matches)) {
        $rangeStart = $matches[1] !== '' ? (int) $matches[1] : null;
        $rangeEnd   = $matches[2] !== '' ? (int) $matches[2] : null;

        if ($rangeStart === null && $rangeEnd !== null) {
            $start = max(0, $length - $rangeEnd);
        } elseif ($rangeStart !== null) {
            $start = min($rangeStart, $end);
            if ($rangeEnd !== null && $rangeEnd >= $start && $rangeEnd <= $end) {
                $end = $rangeEnd;
            }
        }

        $status = 206;
    }

    $outputLength = $supportsRange ? ($end - $start + 1) : $length;

    if (!headers_sent()) {
        if ($status === 206) {
            http_response_code(206);
        }
        header('Content-Type: ' . $mime);
        if ($supportsRange) {
            header('Accept-Ranges: bytes');
            if ($status === 206) {
                header(sprintf('Content-Range: bytes %d-%d/%d', $start, $end, $length));
                header('Content-Length: ' . $outputLength);
            } else {
                header('Content-Length: ' . $length);
            }
        } elseif ($length !== false) {
            header('Content-Length: ' . $length);
        }
        header('Cache-Control: private, max-age=300');
    }

    $handle = fopen($filePath, 'rb');
    if ($handle === false) {
        Http::json(['status' => 'error', 'message' => 'Unable to open file for preview.'], 500);
    }

    if ($supportsRange && $start > 0) {
        fseek($handle, $start);
    }

    $bytesSent = 0;
    $chunkSize = 1024 * 1024; // 1MB chunks to balance throughput and memory
    while (!feof($handle)) {
        if ($supportsRange) {
            $remaining = $outputLength - $bytesSent;
            if ($remaining <= 0) {
                break;
            }
            $readLength = (int) min($chunkSize, $remaining);
        } else {
            $readLength = $chunkSize;
        }

        $buffer = fread($handle, $readLength);
        if ($buffer === false) {
            break;
        }

        echo $buffer;
        $bytesSent += strlen($buffer);
        if ($supportsRange && $bytesSent >= $outputLength) {
            break;
        }
        if (ob_get_level() > 0) {
            ob_flush();
        }
        flush();
    }

    fclose($handle);
    exit;
});

$router->post('/admin/files/settings', function () use ($fileManagerProjectRoot, $fileManagerResolveConfiguredRoot, $fileManagerDescribeRoot, $fileManagerNormaliseSlashes, $fileManagerDefaultRelativeRoot, $fileManagerSanitiseConfigValue)
{
    $input             = isset($_POST['root']) ? (string) $_POST['root'] : '';
    $cleanInput        = trim($fileManagerNormaliseSlashes($input));
    $normalizedProject = $fileManagerNormaliseSlashes($fileManagerProjectRoot);

    if ($cleanInput === '') {
        $relative = $fileManagerDefaultRelativeRoot;
    } else {
        $isAbsolute = str_starts_with($cleanInput, '/') || preg_match('/^[A-Za-z]:\//', $cleanInput) === 1;
        if ($isAbsolute) {
            if (!str_starts_with($cleanInput, $normalizedProject)) {
                Http::json(['status' => 'error', 'message' => 'Root path must be inside the project directory.'], 422);
            }
            $relative = trim(substr($cleanInput, strlen($normalizedProject)), '/');
        } else {
            $relative = trim($cleanInput, '/');
        }

        if ($relative === '' || $relative === '.') {
            $relative = $fileManagerDefaultRelativeRoot;
        }
    }

    $relative              = $fileManagerSanitiseConfigValue($relative);
    [$absolute, $relative] = $fileManagerResolveConfiguredRoot($relative);

    if (!is_dir($absolute) && !Files::createDirectory($absolute)) {
        Http::json(['status' => 'error', 'message' => 'Unable to create the requested directory.'], 500);
    }

    $absoluteReal       = realpath($absolute) ?: $absolute;
    $normalizedAbsolute = $fileManagerNormaliseSlashes($absoluteReal);
    if (!str_starts_with($normalizedAbsolute, $normalizedProject)) {
        Http::json(['status' => 'error', 'message' => 'Root path must be inside the project directory.'], 422);
    }

    try {
        Config::set('file_manager.root', $relative);
    } catch (\Throwable $e) {
        Http::json([
            'status'  => 'error',
            'message' => 'Unable to save settings. ' . $e->getMessage(),
        ], 500);
    }

    $meta = $fileManagerDescribeRoot($absoluteReal, $relative);

    Http::json([
        'status'  => 'ok',
        'message' => 'Settings updated.',
        'meta'    => $meta,
    ]);
});


$router->get('/admin/settings', function ()
{
    $flash = $_SESSION['settings_flash'] ?? [];
    unset($_SESSION['settings_flash']);

    $defaults = [
        'site_title'     => Config::get('site.title', 'PHP App'),
        'primary_color'  => Config::get('theme.primary_color', '#0d6efd') ?? '#0d6efd',
        'openai_api_key' => Config::get('services.openai.api_key', '') ?? '',
    ];

    $old      = $flash['old'] ?? [];
    $settings = array_merge($defaults, array_intersect_key($old, $defaults));

    $diskBasePath = __DIR__;
    $diskTotalRaw = @disk_total_space($diskBasePath);
    $diskFreeRaw  = @disk_free_space($diskBasePath);
    $diskData     = null;

    if (is_numeric($diskTotalRaw) && $diskTotalRaw > 0 && is_numeric($diskFreeRaw)) {
        $diskTotal   = (int) max(0, $diskTotalRaw);
        $diskFree    = (int) max(0, min($diskFreeRaw, $diskTotal));
        $diskUsed    = max(0, $diskTotal - $diskFree);
        $diskPercent = $diskTotal === 0 ? 0 : ($diskUsed / $diskTotal) * 100;
        $diskPercent = max(0, min($diskPercent, 100));

        $diskData = [
            'percent' => (int) round($diskPercent),
            'used'    => Format::bytes($diskUsed),
            'free'    => Format::bytes($diskFree),
            'total'   => Format::bytes($diskTotal),
        ];
    }

    $maxExecutionValue = ini_get('max_execution_time');
    $maxExecution      = is_numeric($maxExecutionValue) && (int) $maxExecutionValue > 0
        ? sprintf('%ss', (int) $maxExecutionValue)
        : 'Unlimited';

    $memoryLimitValue = ini_get('memory_limit');
    $memoryLimit      = $memoryLimitValue === false
        ? 'N/A'
        : ($memoryLimitValue === '-1' ? 'Unlimited' : strtoupper((string) $memoryLimitValue));

    $displayErrorsValue = ini_get('display_errors');
    $displayErrorsBool  = filter_var($displayErrorsValue, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
    if ($displayErrorsBool === null) {
        $displayErrors = is_string($displayErrorsValue) && $displayErrorsValue !== ''
            ? ucfirst(strtolower($displayErrorsValue))
            : 'Off';
    } else {
        $displayErrors = $displayErrorsBool ? 'On' : 'Off';
    }

    $stats = [
        'php_version' => PHP_VERSION,
        'environment' => App::isProduction() ? 'Production' : 'Development',
        'database'    => 'MySQL',
        'limits'      => [
            'max_execution_time'  => $maxExecution,
            'upload_max_filesize' => strtoupper((string) (ini_get('upload_max_filesize') ?: 'N/A')),
            'post_max_size'       => strtoupper((string) (ini_get('post_max_size') ?: 'N/A')),
            'memory_limit'        => $memoryLimit,
        ],
        'system'      => [
            'display_errors' => $displayErrors,
            'timezone'       => date_default_timezone_get() ?: 'UTC',
            'disk'           => $diskData,
        ],
        'extensions'  => (static function ()
        {
            $extensions = get_loaded_extensions();
            if (!is_array($extensions) || !$extensions) {
                return [];
            }

            natcasesort($extensions);

            return array_values($extensions);
        })(),
    ];

    echo TwigHelper::render('admin/settings.twig', [
        'title'    => 'Settings',
        'settings' => $settings,
        'stats'    => $stats,
        'flash'    => [
            'success'      => $flash['success'] ?? null,
            'error'        => $flash['error'] ?? null,
            'errors'       => $flash['errors'] ?? [],
            'error_fields' => $flash['error_fields'] ?? [],
        ],
    ]);
});

$router->post('/admin/settings/core-update', function ()
{
    $downloadUrl = 'https://mzgs.github.io/core.zip';
    $redirect    = '/admin/settings';

    $acceptHeader = isset($_SERVER['HTTP_ACCEPT']) ? (string) $_SERVER['HTTP_ACCEPT'] : '';
    $requestedWith = isset($_SERVER['HTTP_X_REQUESTED_WITH']) ? strtolower((string) $_SERVER['HTTP_X_REQUESTED_WITH']) : '';
    $wantsJson = str_contains(strtolower($acceptHeader), 'application/json') || $requestedWith === 'xmlhttprequest';

    $success    = false;
    $message    = '';
    $statusCode = 200;

    $tempFile   = null;
    $extractDir = null;
    $backupDir  = null;
    $backupCreated = false;
    $projectCorePath = ROOT . DIRECTORY_SEPARATOR . 'core';

    try {
        if (!class_exists(ZipArchive::class)) {
            throw new RuntimeException('ZIP support is not available on this server.');
        }

        $tempFile = tempnam(sys_get_temp_dir(), 'core_update_');
        if ($tempFile === false) {
            throw new RuntimeException('Unable to create a temporary file.');
        }

        if (function_exists('curl_init')) {
            $writeHandle = fopen($tempFile, 'wb');
            if ($writeHandle === false) {
                throw new RuntimeException('Unable to open a temporary file for writing.');
            }

            $ch = curl_init($downloadUrl);
            curl_setopt_array($ch, [
                CURLOPT_FILE           => $writeHandle,
                CURLOPT_FOLLOWLOCATION => true,
                CURLOPT_TIMEOUT        => 60,
                CURLOPT_CONNECTTIMEOUT => 15,
                CURLOPT_FAILONERROR    => true,
                CURLOPT_USERAGENT      => 'CoreUpdater/1.0',
            ]);

            $curlSuccess = curl_exec($ch);
            $curlError   = curl_error($ch);
            $curlErrno   = curl_errno($ch);
            curl_close($ch);
            fclose($writeHandle);

            if ($curlSuccess !== true || $curlErrno) {
                throw new RuntimeException('Unable to download the update package.' . ($curlError ? ' ' . $curlError : ''));
            }
        } else {
            $context = stream_context_create([
                'http' => [
                    'method'  => 'GET',
                    'timeout' => 60,
                    'header'  => "User-Agent: CoreUpdater/1.0\r\n",
                ],
            ]);

            $readHandle = @fopen($downloadUrl, 'rb', false, $context);
            if ($readHandle === false) {
                throw new RuntimeException('Unable to download the update package.');
            }

            $writeHandle = fopen($tempFile, 'wb');
            if ($writeHandle === false) {
                fclose($readHandle);
                throw new RuntimeException('Unable to open a temporary file for writing.');
            }

            stream_copy_to_stream($readHandle, $writeHandle);
            fclose($readHandle);
            fclose($writeHandle);
        }

        $zip = new ZipArchive();
        if ($zip->open($tempFile) !== true) {
            throw new RuntimeException('Unable to open the downloaded archive.');
        }

        $extractDir = sys_get_temp_dir() . DIRECTORY_SEPARATOR . 'core_extract_' . bin2hex(random_bytes(8));
        if (!Files::createDirectory($extractDir)) {
            $zip->close();
            throw new RuntimeException('Unable to prepare the extraction directory.');
        }

        if (!$zip->extractTo($extractDir)) {
            $zip->close();
            throw new RuntimeException('Unable to extract the update package.');
        }
        $zip->close();

        $newCorePath = $extractDir . DIRECTORY_SEPARATOR . 'core';
        if (!is_dir($newCorePath)) {
            $topLevelDirectories = glob($extractDir . '/*', GLOB_ONLYDIR) ?: [];
            foreach ($topLevelDirectories as $dir) {
                if (basename($dir) === 'core') {
                    $newCorePath = $dir;
                    break;
                }

                $nested = $dir . DIRECTORY_SEPARATOR . 'core';
                if (is_dir($nested)) {
                    $newCorePath = $nested;
                    break;
                }
            }
        }

        if (!is_dir($newCorePath)) {
            throw new RuntimeException('The update package does not contain a core directory.');
        }

        if (is_dir($projectCorePath)) {
            $backupDir = $projectCorePath . '_backup_' . date('YmdHis');
            if (!@rename($projectCorePath, $backupDir)) {
                throw new RuntimeException('Unable to create a backup of the existing core directory.');
            }
            $backupCreated = true;
        }

        $copyDirectory = static function (string $source, string $destination) use (&$copyDirectory) {
            if (!is_dir($source)) {
                throw new RuntimeException('Source directory missing: ' . $source);
            }

            if (!is_dir($destination) && !mkdir($destination, 0755, true) && !is_dir($destination)) {
                throw new RuntimeException('Unable to create directory: ' . $destination);
            }

            $items = scandir($source);
            if ($items === false) {
                throw new RuntimeException('Unable to read directory: ' . $source);
            }

            foreach ($items as $item) {
                if ($item === '.' || $item === '..') {
                    continue;
                }

                $sourcePath = $source . DIRECTORY_SEPARATOR . $item;
                $destinationPath = $destination . DIRECTORY_SEPARATOR . $item;

                if (is_dir($sourcePath)) {
                    $copyDirectory($sourcePath, $destinationPath);
                    continue;
                }

                if (!copy($sourcePath, $destinationPath)) {
                    throw new RuntimeException('Unable to copy file: ' . $item);
                }
            }
        };

        $copyDirectory($newCorePath, $projectCorePath);

        if ($backupCreated && $backupDir && is_dir($backupDir)) {
            Files::deleteDirectory($backupDir);
            $backupDir = null;
            $backupCreated = false;
        }

        $success = true;
        $message = 'Core updated successfully.';
    } catch (Throwable $e) {
        if ($backupCreated) {
            if (is_dir($projectCorePath)) {
                Files::deleteDirectory($projectCorePath);
            }

            if ($backupDir && is_dir($backupDir)) {
                @rename($backupDir, $projectCorePath);
                $backupDir = null;
                $backupCreated = false;
            }
        }

        $statusCode = 500;
        $detail = trim((string) $e->getMessage());
        $message = 'Unable to update the core package.' . ($detail !== '' ? ' ' . $detail : '');
    } finally {
        if ($backupDir && is_dir($backupDir)) {
            Files::deleteDirectory($backupDir);
        }

        if ($extractDir && is_dir($extractDir)) {
            Files::deleteDirectory($extractDir);
        }

        if ($tempFile && file_exists($tempFile)) {
            @unlink($tempFile);
        }
    }

    $_SESSION['settings_flash'] = $success
        ? ['success' => $message]
        : ['error' => $message];

    if ($wantsJson) {
        Http::json([
            'status'   => $success ? 'ok' : 'error',
            'message'  => $message,
            'redirect' => $success ? $redirect : null,
        ], $success ? 200 : $statusCode);
    }

    Http::redirect($redirect);
});

$router->post('/admin/settings', function ()
{
    $fields = [
        'site_title'     => isset($_POST['site_title']) ? trim((string) $_POST['site_title']) : '',
        'primary_color'  => isset($_POST['primary_color']) ? trim((string) $_POST['primary_color']) : '',
        'openai_api_key' => isset($_POST['openai_api_key']) ? trim((string) $_POST['openai_api_key']) : '',
    ];

    $errors      = [];
    $errorFields = [];

    if ($fields['site_title'] === '') {
        $errors[]      = 'Site title is required.';
        $errorFields[] = 'site_title';
    }

    if ($fields['primary_color'] === '') {
        $fields['primary_color'] = '#0d6efd';
    }

    if (!preg_match('/^#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})$/', $fields['primary_color'])) {
        $errors[]      = 'Primary color must be a valid hex value.';
        $errorFields[] = 'primary_color';
    }

    if ($errors) {
        $_SESSION['settings_flash'] = [
            'error'        => 'Please review the highlighted issues.',
            'errors'       => $errors,
            'error_fields' => $errorFields,
            'old'          => $fields,
        ];
        Http::redirect('/admin/settings');
        return;
    }

    try {
        $normalisedColor = strtolower($fields['primary_color']);
        if (strlen($normalisedColor) === 4) {
            $normalisedColor = sprintf(
                '#%1$s%1$s%2$s%2$s%3$s%3$s',
                $normalisedColor[1],
                $normalisedColor[2],
                $normalisedColor[3]
            );
        }

        $fields['primary_color'] = $normalisedColor;

        Config::set('site.title', $fields['site_title']);
        Config::set('theme.primary_color', $fields['primary_color']);

        $apiKey = $fields['openai_api_key'] !== '' ? $fields['openai_api_key'] : null;
        Config::set('services.openai.api_key', $apiKey);

        $_SESSION['settings_flash'] = [
            'success' => 'Settings saved successfully.',
        ];
    } catch (\Throwable $e) {
        $_SESSION['settings_flash'] = [
            'error' => 'Unable to save settings. Please try again.',
            'old'   => $fields,
        ];
    }

    Http::redirect('/admin/settings');
});

$router->get('/admin/users', function ()
{
    $c = new Crud('users');
    $c->columns(['id', 'name', 'email', 'created_at']);
    $c->enable_batch_delete();
    $c->change_type('password', 'password');
    $c->pass_default('created_at', date('Y-m-d H:i:s'));

    echo TwigHelper::render('crud.twig', [
        'title' => 'Users',
        'crud'  => $c->render(),
    ]);
});

// logs
$router->get('/admin/logs', function ()
{
    $c = new Crud('logs');
    $c->columns(['level', 'message', 'context', 'created_at']);
    $c->order_by("id", "DESC");
    $c->enable_edit(false);
    $c->setPanelWidth('40%');
    $c->column_cut('context', 70);
    $c->column_class('context', 'small');
    $c->enable_batch_delete();


    $c->change_type('context,meta', 'json');

    $c->column_callback('level', [CoreCallback::class, 'logLevelBadge']);

    echo TwigHelper::render('crud.twig', [
        'title' => 'Logs',
        'crud'  => $c->render(),
    ]);
});

$router->get('/admin/db-editor', function ()
{

    echo TwigHelper::render('crud.twig', [
        'title' => 'Database Editor',
        'crud'  => DatabaseEditor::render(),
    ]);
});
