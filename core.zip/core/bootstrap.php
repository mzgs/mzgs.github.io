<?php

use Bramus\Router\Router;
use Mzgs\Core\CoreGithubUpdater;
use Mzgs\Core\Navigation\NavigationRepository;
use FastCrud\{Crud, CrudConfig, DatabaseEditor};
use PhpHelper\{DB, App, Http, Logs, AIChat, Config, Countries, TwigHelper, AuthManager, PrettyErrorHandler};
require_once 'vendor/autoload.php';


// ---- PRODUCTION ----
if (App::isProduction()) {
    PrettyErrorHandler::init(['display' => false, 'log_errors' => true]);
    DB::mysql(PROD_DB, PROD_USER, PROD_PASS);

}
// ---- LOCAL ----
else {
    if (App::isCli()) {
        App::cliMenu(DB::cliBackupRestoreOptions(LOCAL_DB, LOCAL_USER, LOCAL_PASS) + [
            "Update core to github" => [
                'label' => 'Update core.zip on GitHub',
                'run'   => static function (): int {
                    return CoreGithubUpdater::run();
                },
            ],
        ]);

        return;
    }

    PrettyErrorHandler::init(['display' => true, 'log_errors' => false]);
    DB::mysql(LOCAL_DB, LOCAL_USER, LOCAL_PASS);
}

// Initialize authentication system with 365-day remember-me cookies
AuthManager::init([
    'remember_me'       => true,
    'remember_duration' => 60 * 60 * 24 * 365,
]);
// AuthManager::createUsersTable();
// AuthManager::register('debf2@ymail.com', '1');


// Initialize configuration system
Config::init();
// Config::createConfigTable();

// Initialize logging system
Logs::init();
// Logs::createLogsTable();

AIChat::init(['api_key' => Config::get('services.openai.api_key')]);

TwigHelper::init([ROOT . '/app/templates', ROOT . '/core/templates']);
TwigHelper::addGlobal('auth_user', AuthManager::user());
TwigHelper::addGlobal('auth_is_logged_in', AuthManager::isLoggedIn());

$siteTitle    = Config::get('site.title', 'PHP App');
$primaryColor = Config::get('theme.primary_color', '#0668D1');

TwigHelper::addGlobal('site_title', $siteTitle);
TwigHelper::addGlobal('primary_color', $primaryColor);

CrudConfig::$hide_table_title = true;
CrudConfig::$upload_path      =  ROOT . '/app/public/uploads';
CrudConfig::$upload_serve_path = '/app/public/uploads';
Crud::init(DB::pdo());
DatabaseEditor::init();



TwigHelper::addGlobal('navigation_groups', NavigationRepository::grouped());
TwigHelper::addFunction('country_name', static function (string $code): string
{
    $value = Countries::nameWithFlag($code);
    return $value ?? strtoupper($code);
}, ['is_safe' => ['html']]);

// ------ Initialize routers --------
$router = new Router();

$router->before('GET|POST|PUT|DELETE', '/admin(/.*)?', fn() => AuthManager::requireAuth(fn() => Http::redirect('/login', 302, true)));

// Set custom 404 handler
$renderNotFound = static function (): void
{
    if (!headers_sent()) {
        http_response_code(404);
    }

    echo TwigHelper::render('404.twig', ['title' => '404 - Page Not Found', 'path' => $_SERVER['REQUEST_URI'] ?? 'unknown']);
};

$router->set404($renderNotFound);



include  ROOT . '/core/core_routes.php';
include  ROOT . '/app/admin_routes.php';
include  ROOT . '/app/frontend_routes.php';
 
// Bramus Router 1.6.1 indexes the current method's route bucket before
// running the 404 handler. Ensure methods without explicit routes still
// reach the shared 404 renderer cleanly.
$router->match('PUT|DELETE|PATCH|OPTIONS', '/.*', $renderNotFound);


$router->run();
