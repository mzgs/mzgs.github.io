<?php

namespace Mzgs\Core\Navigation;

use PhpHelper\DB;

class NavigationRepository
{
    private const TABLE = 'navigation';

    public static function grouped(): array
    {
        $rows = DB::getRows(
            'SELECT * FROM `navigation` ORDER BY `section`, `sort_order`, `label`'
        );

        $groups = [];
        foreach ($rows as $row) {
            $row['url'] = self::normalizeUrl($row['url'] ?? '');
            $section = self::normalizeSection($row['section'] ?? 'Main');
            $row['section'] = $section;
            if (!isset($groups[$section])) {
                $groups[$section] = [];
            }
            $groups[$section][] = $row;
        }
        foreach (['Main', 'Admin Main', 'Admin', 'Frontend Footer', 'Admin Footer'] as $sectionName) {
            if (!isset($groups[$sectionName])) {
                $groups[$sectionName] = [];
            }
        }

        $mainLinks = $groups['Main'];
        unset($groups['Main']);

        $adminMainLinks = $groups['Admin Main'];
        unset($groups['Admin Main']);

        $adminLinks = $groups['Admin'];
        unset($groups['Admin']);

        $frontendFooterLinks = $groups['Frontend Footer'];
        unset($groups['Frontend Footer']);

        $adminFooterLinks = $groups['Admin Footer'];
        unset($groups['Admin Footer']);

        $ordered = [
            'Main' => $mainLinks,
        ];

        if ($groups) {
            ksort($groups, SORT_NATURAL | SORT_FLAG_CASE);
            foreach ($groups as $section => $links) {
                $ordered[$section] = $links;
            }
        }

        $ordered['Admin Main'] = $adminMainLinks;
        $ordered['Admin'] = $adminLinks;
        $ordered['Frontend Footer'] = $frontendFooterLinks;
        $ordered['Admin Footer'] = $adminFooterLinks;

        return $ordered;
    }

    public static function find(int $id): ?array
    {
        $row = DB::getRow('SELECT * FROM `navigation` WHERE `id` = ?', [$id]);
        if (!$row) {
            return null;
        }

        $row['url'] = self::normalizeUrl($row['url'] ?? '');
        $row['section'] = self::normalizeSection($row['section'] ?? 'Main');
        return $row;
    }

    public static function create(array $data): int
    {
        $clean = self::prepareData($data);
        $sort = (int) DB::getValue(
            'SELECT COALESCE(MAX(`sort_order`), 0) + 1 FROM `navigation` WHERE `section` = ?',
            [$clean['section']]
        );
        $clean['sort_order'] = $sort;

        return (int) DB::insert(self::TABLE, $clean);
    }

    public static function update(int $id, array $data): bool
    {
        $clean = self::prepareData($data);

        $current = self::find($id);
        if (!$current) {
            return false;
        }

        if ($current['section'] !== $clean['section']) {
            $clean['sort_order'] = (int) DB::getValue(
                'SELECT COALESCE(MAX(`sort_order`), 0) + 1 FROM `navigation` WHERE `section` = ?',
                [$clean['section']]
            );
        }

        $affected = DB::update(
            self::TABLE,
            $clean,
            '`id` = :where_id',
            ['where_id' => $id]
        );
        return $affected > 0;
    }

    public static function delete(int $id): bool
    {
        $affected = DB::delete(self::TABLE, '`id` = ?', [$id]);
        return $affected > 0;
    }

    public static function duplicate(int $id): ?int
    {
        $original = self::find($id);
        if (!$original) {
            return null;
        }

        $section = self::normalizeSection($original['section'] ?? 'Main');
        $label = $original['label'] ?? '';
        $label = $label !== '' ? $label : 'Navigation Link';

        $duplicateLabel = self::resolveDuplicateLabel($label, $section);

        $data = [
            'label' => $duplicateLabel,
            'url' => $original['url'] ?? '',
            'icon' => $original['icon'] ?? null,
            'section' => $section,
        ];

        return self::create($data);
    }

    public static function reorder(array $sectionOrders): void
    {
        DB::transaction(function () use ($sectionOrders) {
            foreach ($sectionOrders as $section => $ids) {
                $section = self::normalizeSection($section);
                $position = 1;
                foreach ($ids as $id) {
                    $id = (int) $id;
                    if ($id <= 0) {
                        continue;
                    }

                    DB::update(
                        self::TABLE,
                        [
                            'section' => $section,
                            'sort_order' => $position,
                        ],
                        '`id` = :where_id',
                        ['where_id' => $id]
                    );

                    $position++;
                }
            }
        });
    }

    private static function prepareData(array $data): array
    {
        $label = trim((string)($data['label'] ?? ''));
        $url = self::normalizeUrl((string)($data['url'] ?? ''));
        $icon = trim((string)($data['icon'] ?? '')) ?: null;
        $section = self::normalizeSection($data['section'] ?? 'Main');

        if ($label === '' || $url === '') {
            throw new \InvalidArgumentException('Label and URL are required.');
        }

        return [
            'label' => $label,
            'url' => $url,
            'icon' => $icon,
            'section' => $section,
        ];
    }

    private static function normalizeUrl(string $url): string
    {
        $url = trim($url);
        if ($url === '') {
            return '';
        }

        if (preg_match('/^(?:[a-z][a-z0-9+.-]*:|\/\/|#|\?)/i', $url) === 1) {
            return $url;
        }

        return '/' . ltrim($url, '/');
    }

    private static function normalizeSection($section): string
    {
        $section = trim((string) $section);
        if ($section === '') {
            return 'Main';
        }

        if ($section === 'Footer') {
            return 'Frontend Footer';
        }

        return $section;
    }

    private static function resolveDuplicateLabel(string $label, string $section): string
    {
        $suffixBase = ' (copy)';
        $candidate = $label . $suffixBase;

        if (!self::labelExists($candidate, $section)) {
            return self::truncateLabel($candidate);
        }

        $counter = 2;
        while (true) {
            $candidate = $label . $suffixBase . ' ' . $counter;
            if (!self::labelExists($candidate, $section)) {
                return self::truncateLabel($candidate);
            }
            $counter++;
            if ($counter > 50) {
                return self::truncateLabel($label . ' ' . uniqid());
            }
        }
    }

    private static function labelExists(string $label, string $section): bool
    {
        $count = (int) DB::getValue(
            'SELECT COUNT(*) FROM `navigation` WHERE `section` = ? AND `label` = ?',
            [$section, $label]
        );

        return $count > 0;
    }

    private static function truncateLabel(string $label): string
    {
        $max = 150;

        $length = function_exists('mb_strlen') ? mb_strlen($label) : strlen($label);
        if ($length <= $max) {
            return $label;
        }

        $slice = function_exists('mb_substr')
            ? mb_substr($label, 0, $max - 3)
            : substr($label, 0, $max - 3);

        return $slice . '...';
    }
}
