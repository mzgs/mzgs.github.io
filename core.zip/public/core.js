;(function ($) {
    $(function () {
        initSidebar();
        initMobileSidebar();
        highlightActiveNavLink();
        setInlineEdits();
        initTableSortable();
        initThemeToggle();
        initDatePresets();
    });

    //wdwdw22
    function json_parse_clean(data) {
        const htmlDecode = function (value) {
            return $('<textarea>').html(value).text();
        };

        const clearJsonData = function (payload) {
            return payload.replace(/&quot;/g, '"');
        };

        return JSON.parse(clearJsonData(htmlDecode(data).replaceAll("'", '"')));
    }

    // Expose json_parse_clean globally
    window.json_parse_clean = json_parse_clean;
    window.initTableSortable = initTableSortable;

    // Loading indicator functions
    function showLoadingIndicator() {
        if ($('#loading-indicator').length) {
            return;
        }
        const $loader = $('<div>', {
            id: 'loading-indicator',
            css: {
                position: 'fixed',
                top: 0,
                left: 0,
                width: '100%',
                height: '100%',
                backgroundColor: 'rgba(0, 0, 0, 0.5)',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                zIndex: 9999
            }
        }).append(
            $('<div>', {
                class: 'spinner-border text-light',
                role: 'status'
            }).append(
                $('<span>', {
                    class: 'visually-hidden',
                    text: 'Loading...'
                })
            )
        );
        $('body').append($loader);
    }

    function hideLoadingIndicator() {
        $('#loading-indicator').remove();
    }

    // Dialog function
    function showDialog(title, content) {
        const dialogId = 'custom-dialog-modal';
        $('#' + dialogId).remove();

        const $modal = $('<div>', {
            class: 'modal fade',
            id: dialogId,
            tabindex: '-1',
            'aria-labelledby': dialogId + 'Label',
            'aria-hidden': 'true'
        }).append(
            $('<div>', {
                class: 'modal-dialog modal-lg modal-dialog-scrollable'
            }).append(
                $('<div>', {
                    class: 'modal-content'
                }).append(
                    $('<div>', {
                        class: 'modal-header'
                    }).append(
                        $('<h5>', {
                            class: 'modal-title',
                            id: dialogId + 'Label',
                            text: title
                        }),
                        $('<button>', {
                            type: 'button',
                            class: 'btn-close',
                            'data-bs-dismiss': 'modal',
                            'aria-label': 'Close'
                        })
                    ),
                    $('<div>', {
                        class: 'modal-body'
                    }).html(content)
                )
            )
        );

        $('body').append($modal);
        const modal = new bootstrap.Modal($modal[0]);
        modal.show();
    }

    // Expose functions globally
    window.showLoadingIndicator = showLoadingIndicator;
    window.hideLoadingIndicator = hideLoadingIndicator;
    window.showDialog = showDialog;
    window.setInlineEdits = setInlineEdits;

    function scrollToTopButton() {
        const $button = $('<button>', {
            id: 'go-top-btn',
            class: 'btn btn-blue',
            html: "<i class='fas fa-arrow-up' />"
        }).css({
            position: 'fixed',
            bottom: '20px',
            right: '30px',
            zIndex: 99,
            display: 'none'
        });

        $('body').append($button);

        $(window).on('scroll', function () {
            if ($(this).scrollTop() > 20) {
                $button.show();
            } else {
                $button.hide();
            }
        });

        $button.on('click', function () {
            $('html, body').animate({ scrollTop: 0 }, 'fast');
        });
    }

    function initDatePresets() {
        const $groups = $('.date-presets');
        if (!$groups.length) {
            return;
        }

        const hasPicker = function () {
            return Boolean(window.jQuery && window.jQuery.fn && typeof window.jQuery.fn.daterangepicker === 'function');
        };

        const onPickerReady = function (callback) {
            if (hasPicker() || window.__daterangepickerBundleReady) {
                callback();
                return;
            }

            const handler = function () {
                window.removeEventListener('daterangepicker:ready', handler);
                callback();
            };

            window.addEventListener('daterangepicker:ready', handler);
        };

        const redirectWithRange = function (parameter, start, end) {
            if (!parameter || !start || !end) {
                return;
            }

            try {
                const url = new URL(window.location.href);
                url.searchParams.set(parameter, 'custom');
                url.searchParams.set(parameter + '_start', start);
                url.searchParams.set(parameter + '_end', end);
                window.location.href = url.toString();
                return;
            } catch (error) {
                // Ignore and fallback below
            }

            const base = window.location.href.split('#')[0];
            const glue = base.includes('?') ? '&' : '?';
            window.location.href = base + glue
                + encodeURIComponent(parameter) + '=custom&'
                + encodeURIComponent(parameter + '_start') + '=' + encodeURIComponent(start) + '&'
                + encodeURIComponent(parameter + '_end') + '=' + encodeURIComponent(end);
        };

        const parseInputRange = function (value) {
            return value
                ? value.split(' - ').map(function (chunk) {
                    return chunk.trim();
                }).filter(Boolean)
                : null;
        };

        $groups.each(function () {
            const $group = $(this);
            const parameter = String($group.data('parameter') || '').trim();
            if (!parameter) {
                return;
            }

            const $customContainer = $group.find('.custom-date-range');
            const $input = $customContainer.find('.date-range-input');
            if (!$customContainer.length || !$input.length) {
                return;
            }

            const setCustomActive = function (state) {
                $customContainer.toggleClass('custom-active', Boolean(state));
            };

            setCustomActive(String($group.data('active') || '') === 'custom');

            const format = String($input.data('format') || 'YYYY-MM-DD');
            const startValue = String($input.data('start') || '').trim();
            const endValue = String($input.data('end') || '').trim();

            const handleRangeSelection = function (start, end) {
                if (!start || !end) {
                    return;
                }
                const value = start + ' - ' + end;
                $input.val(value).data('start', start).data('end', end);
                setCustomActive(true);
                redirectWithRange(parameter, start, end);
            };

            const applyInitialValue = function () {
                if (startValue && endValue) {
                    $input.val(startValue + ' - ' + endValue);
                }
            };

            const attachDateRangePicker = function () {
                if ($input.data('daterangepickerAttached') || !hasPicker()) {
                    return;
                }

                const options = {
                    autoUpdateInput: false,
                    locale: {
                        format: format,
                        cancelLabel: 'Clear'
                    },
                    startDate: startValue || undefined,
                    endDate: endValue || undefined
                };

                try {
                    $input.daterangepicker(options);
                    $input.data('daterangepickerAttached', true);
                } catch (error) {
                    $input.data('daterangepickerAttached', false);
                }

                $input.on('apply.daterangepicker', function (ev, picker) {
                    const startDate = picker.startDate && picker.startDate.format ? picker.startDate.format(format) : null;
                    const endDate = picker.endDate && picker.endDate.format ? picker.endDate.format(format) : null;
                    handleRangeSelection(startDate, endDate);
                });

                $input.on('cancel.daterangepicker', function () {
                    $input.val('').data('start', '').data('end', '');
                });

                applyInitialValue();
            };

            onPickerReady(attachDateRangePicker);

            $input.on('focus', function () {
                setCustomActive(true);
            });

            if (!hasPicker()) {
                applyInitialValue();
            }

            $input.on('change', function () {
                const parsed = parseInputRange($(this).val());
                if (parsed && parsed.length === 2) {
                    handleRangeSelection(parsed[0], parsed[1]);
                }
            });
        });
    }

    function initSidebar() {
        const $body = $('body');
        const $sidebar = $('#adminSidebar');
        const $fallbackSidebar = $('.sidebar');
        const $resolvedSidebar = $sidebar.length ? $sidebar : $fallbackSidebar;

        if (!$resolvedSidebar.length) {
            return;
        }

        const $toggleButton = $('#sidebarToggle');
        const $fallbackToggle = $('.navbar-toggler');
        const $resolvedToggle = $toggleButton.length ? $toggleButton : $fallbackToggle;
        const $closeButton = $('#sidebarClose');
        const $backdrop = $('#sidebarBackdrop');

        const openSidebar = function () {
            if ($(window).width() >= 992) {
                return;
            }
            $body.addClass('sidebar-open');
            $resolvedSidebar.addClass('open');
        };

        const closeSidebar = function () {
            $body.removeClass('sidebar-open');
            $resolvedSidebar.removeClass('open');
        };

        $resolvedToggle.on('click.sidebar', function (event) {
            event.preventDefault();
            openSidebar();
        });

        $closeButton.on('click.sidebar', function (event) {
            event.preventDefault();
            closeSidebar();
        });

        $backdrop.on('click.sidebar', closeSidebar);

        $resolvedSidebar.on('click.sidebar', 'a.nav-link', function () {
            if ($(window).width() >= 992) {
                return;
            }
            closeSidebar();
        });

        $(window).on('resize.sidebar', function () {
            if ($(window).width() >= 992) {
                closeSidebar();
            }
        });

        $(document).on('keydown.sidebar', function (event) {
            if (event.key === 'Escape') {
                closeSidebar();
            }
        });
    }

    function highlightActiveNavLink() {
        const $links = $('.sidebar a.nav-link, .sidebar a');
        if (!$links.length) {
            return;
        }

        const currentPath = normalisePath(window.location.pathname);

        $links.each(function () {
            const $link = $(this);
            const href = $link.attr('href');
            if (!href) {
                return;
            }

            let linkPath;
            try {
                linkPath = normalisePath(new URL(href, window.location.origin).pathname);
            } catch (error) {
                linkPath = normalisePath(href);
            }

            if (linkPath === currentPath) {
                $link.addClass('active').attr('aria-current', 'page');
            } else {
                $link.removeClass('active').removeAttr('aria-current');
            }
        });
    }

    function normalisePath(pathname) {
        if (!pathname) {
            return '/';
        }
        const path = pathname.split('?')[0].split('#')[0];
        if (path.length > 1 && path.endsWith('/')) {
            return path.slice(0, -1);
        }
        return path || '/';
    }

    function setInlineEdits() {
        $('.editable').each(function () {
            const $editable = $(this);

            if ($editable.data('inlineBound') === '1') {
                return;
            }

            $editable.data('inlineBound', '1').attr('data-inline-bound', '1');
            applyEditableDisplay($editable);

            $editable.on('click.inlineEdit', function () {
                if ($editable.find('.editable-input').length) {
                    return;
                }

                const updateUrl = $editable.data('updateUrl')
                    || $editable.attr('data-update-url')
                    || $editable.data('url')
                    || $editable.attr('data-url');

                if (!updateUrl) {
                    return;
                }

                const originalValue = $editable.data('value') !== undefined
                    ? $editable.data('value')
                    : $.trim($editable.text());

                const containerWidth = getEditableContainerWidth($editable);
                const desiredWidth = resolveEditableInputWidth($editable, originalValue, containerWidth);
                let resolvedTextAlign = '';

                try {
                    const computed = window.getComputedStyle($editable.get(0));
                    if (computed && computed.textAlign) {
                        resolvedTextAlign = computed.textAlign;
                    }
                } catch (error) {
                    resolvedTextAlign = '';
                }

                const inputTypeRaw = $editable.data('inputType') || $editable.attr('data-input-type') || 'text';
                const inputType = String(inputTypeRaw).toLowerCase();
                const customInputClass = $editable.data('inputClass') || $editable.attr('data-input-class') || '';
                const inputClasses = ['editable-input'];

                if (customInputClass) {
                    inputClasses.push(customInputClass);
                } else if (inputType === 'select') {
                    inputClasses.push('form-select form-select-sm');
                }

                let $input;

                if (inputType === 'select') {
                    $input = $('<select>', {
                        class: inputClasses.join(' ').trim()
                    });

                    const options = normaliseEditableOptions(getEditableOptions($editable));
                    let hasSelected = false;
                    const originalString = originalValue === undefined || originalValue === null ? '' : String(originalValue);

                    options.forEach(function (option) {
                        if (!option) {
                            return;
                        }

                        const value = option.value === undefined || option.value === null
                            ? ''
                            : String(option.value);
                        const label = option.label === undefined || option.label === null
                            ? value
                            : String(option.label);
                        const isSelected = value === originalString;
                        if (isSelected) {
                            hasSelected = true;
                        }

                        $input.append($('<option>', {
                            value: value,
                            text: label,
                            selected: isSelected
                        }));
                    });

                    if (!hasSelected && originalString !== '') {
                        $input.prepend($('<option>', {
                            value: originalString,
                            text: originalString,
                            selected: true
                        }));
                    }
                } else {
                    $input = $('<input>', {
                        type: inputType,
                        value: originalValue,
                        class: inputClasses.join(' ').trim()
                    });

                    if (desiredWidth && isFinite(desiredWidth) && desiredWidth > 0) {
                        $input
                            .data('initialWidth', desiredWidth)
                            .attr('data-initial-width', desiredWidth);
                    }
                }

                $editable.removeClass('is-placeholder').empty().append($input);

                if (resolvedTextAlign) {
                    $input.css('textAlign', resolvedTextAlign);
                }

                $input.trigger('focus');

                if (inputType !== 'select' && $input[0] && $input[0].setSelectionRange) {
                    const length = $input.val().length;
                    $input[0].setSelectionRange(length, length);
                }

                if (inputType === 'select') {
                    let submissionStarted = false;

                    $input.on('change.inlineEdit', function () {
                        const newValue = $input.val();
                        if (String(newValue ?? '') === String(originalValue ?? '')) {
                            submissionStarted = true;
                            $editable.data('value', originalValue).attr('data-value', originalValue);
                            applyEditableDisplay($editable);
                            return;
                        }

                        submissionStarted = true;
                        const $spinner = $('<div>', { class: 'fas fa-spinner fa-spin ms-1' });
                        $editable.empty().append($spinner);

                        submitInlineUpdate($editable, updateUrl, originalValue, newValue, $spinner);
                    });

                    $input.on('blur.inlineEdit', function () {
                        if (!submissionStarted) {
                            $editable.data('value', originalValue).attr('data-value', originalValue);
                            applyEditableDisplay($editable);
                        }
                    });
                } else {
                    const storedWidth = Number($input.data('initialWidth'));
                    const baseWidth = Number.isFinite(storedWidth) && storedWidth > 0
                        ? storedWidth
                        : (Number.isFinite(desiredWidth) && desiredWidth > 0 ? desiredWidth : 0);
                    const maxWidth = Number.isFinite(containerWidth) && containerWidth > 0
                        ? containerWidth
                        : Math.max(baseWidth, 640);
                    const resizeSettings = {
                        minWidth: Math.max(baseWidth, 48),
                        maxWidth: maxWidth,
                        padding: 12
                    };

                    resizeInput($input, resizeSettings);

                    $input.on('input.inlineEdit', function () {
                        resizeInput($input, resizeSettings);
                    });

                    let submissionStarted = false;

                    const submitValue = function (newValue) {
                        submissionStarted = true;

                        if (String(newValue ?? '') === String(originalValue ?? '')) {
                            $editable.data('value', originalValue).attr('data-value', originalValue);
                            applyEditableDisplay($editable);
                            return;
                        }

                        const $spinner = $('<div>', { class: 'fas fa-spinner fa-spin ms-1' });
                        $editable.empty().append($spinner);
                        submitInlineUpdate($editable, updateUrl, originalValue, newValue, $spinner);
                    };

                    $input.on('keypress.inlineEdit', function (event) {
                        if (event.key === 'Enter') {
                            event.preventDefault();
                            submitValue($input.val());
                        }
                    });

                    $input.on('blur.inlineEdit', function () {
                        if (submissionStarted) {
                            return;
                        }
                        submitValue($input.val());
                    });
                }
            });
        });
    }

    function getEditableOptions($editable) {
        let options = $editable.data('options');

        if (options === undefined) {
            const attr = $editable.attr('data-options');
            if (attr !== undefined) {
                options = attr;
            }
        }

        if (options === undefined || options === null || options === '') {
            return [];
        }

        if (Array.isArray(options)) {
            return options;
        }

        if (typeof options === 'string') {
            const trimmed = options.trim();
            if (!trimmed) {
                return [];
            }

            try {
                const parsed = JSON.parse(trimmed);
                if (Array.isArray(parsed)) {
                    return parsed;
                }
            } catch (error) {
                return trimmed.split(',').map(function (item) {
                    return item.trim();
                }).filter(function (item) {
                    return item !== '';
                });
            }
        }

        if (typeof options === 'object') {
            return Object.keys(options).sort().map(function (key) {
                return options[key];
            });
        }

        return [];
    }

    function normaliseEditableOptions(options) {
        if (!Array.isArray(options)) {
            return [];
        }

        return options.reduce(function (accumulator, option) {
            if (option === null || option === undefined) {
                return accumulator;
            }

            if (typeof option === 'string' || typeof option === 'number' || typeof option === 'boolean') {
                const value = String(option);
                accumulator.push({ value: value, label: value });
                return accumulator;
            }

            if (typeof option === 'object') {
                const valueSource = Object.prototype.hasOwnProperty.call(option, 'value')
                    ? option.value
                    : (Object.prototype.hasOwnProperty.call(option, 'id') ? option.id : '');

                const value = valueSource === null || valueSource === undefined ? '' : String(valueSource);

                const labelSource = Object.prototype.hasOwnProperty.call(option, 'label')
                    ? option.label
                    : (Object.prototype.hasOwnProperty.call(option, 'text') ? option.text : null);

                const label = labelSource === null || labelSource === undefined ? value : String(labelSource);

                accumulator.push({ value: value, label: label });
            }

            return accumulator;
        }, []);
    }

    function resolveEditableDisplayValue($editable, value) {
        const options = normaliseEditableOptions(getEditableOptions($editable));

        if (options.length) {
            const match = options.find(function (option) {
                return String(option.value) === value;
            });

            if (match && match.label !== undefined) {
                return String(match.label);
            }
        }

        return value;
    }

    function submitInlineUpdate($editable, updateUrl, originalValue, newValue, $spinner) {
        const params = { value: newValue };

        $.each($editable.get(0).attributes, function (_, attr) {
            if (!attr.name.startsWith('data-')) {
                return;
            }

            const key = attr.name.slice(5);
            if (!key || key === 'update-url' || key === 'value' || key === 'empty-display' || key === 'icon-target' || key === 'input-type' || key === 'inline-bound') {
                return;
            }

            params[key] = attr.value;
        });

        if (!Object.prototype.hasOwnProperty.call(params, 'field')) {
            $spinner.remove();
            $editable.data('value', originalValue).attr('data-value', originalValue);
            applyEditableDisplay($editable);
            return;
        }

        $.ajax({
            url: updateUrl,
            method: 'POST',
            data: params,
            dataType: 'text'
        })
            .then(function (response, textStatus, jqXHR) {
                const contentType = jqXHR.getResponseHeader('content-type') || '';
                let payload;

                if (contentType.indexOf('application/json') !== -1) {
                    try {
                        payload = JSON.parse(response);
                    } catch (error) {
                        payload = { value: response };
                    }
                } else {
                    payload = { value: response };
                }

                const nextValue = Object.prototype.hasOwnProperty.call(payload, 'value')
                    ? String(payload.value ?? '')
                    : String(newValue ?? '');

                $editable.data('value', nextValue).attr('data-value', nextValue);
                applyEditableDisplay($editable);
                $spinner.remove();

                $editable.trigger('inlineedit:updated', { value: nextValue });
            })
            .fail(function (jqXHR) {
                console.error('Inline edit failed', jqXHR);
                $spinner.remove();
                $editable.data('value', originalValue).attr('data-value', originalValue);
                applyEditableDisplay($editable);

                $editable.trigger('inlineedit:error', {
                    value: originalValue,
                    error: jqXHR
                });
            });
    }

    function applyEditableDisplay($editable) {
        if ($editable.data('value') === undefined) {
            const initialValue = $.trim($editable.text());
            $editable.data('value', initialValue).attr('data-value', initialValue);
        }

        const rawValue = $editable.data('value') ?? '';
        const value = rawValue === undefined || rawValue === null ? '' : String(rawValue);
        const placeholder = $editable.data('emptyDisplay')
            || $editable.attr('data-empty-display')
            || '';
        const shouldShowPlaceholder = $.trim(value) === '' && placeholder !== '';
        const display = shouldShowPlaceholder ? placeholder : resolveEditableDisplayValue($editable, value);

        $editable.text(display).toggleClass('is-placeholder', shouldShowPlaceholder);

        updateIconPreview($editable, $.trim(value));
    }

    function updateIconPreview($editable, value) {
        const targetId = $editable.data('iconTarget') || $editable.attr('data-icon-target');
        if (!targetId) {
            return;
        }

        const $preview = $('#' + targetId);
        if (!$preview.length) {
            return;
        }

        $preview.empty();
        const $icon = $('<i>');

        if (value) {
            $icon.attr('class', value);
            $preview.removeClass('text-muted');
        } else {
            $icon.attr('class', 'fa-regular fa-circle');
            $preview.addClass('text-muted');
        }

        $preview.append($icon);
    }

    function getEditableContainerWidth($editable) {
        if (!$editable || !$editable.length) {
            return 0;
        }

        const $cell = $editable.closest('td, th');
        if ($cell.length) {
            return $cell.innerWidth();
        }

        const $parent = $editable.parent();
        return $parent.length ? $parent.innerWidth() : 0;
    }

    function resolveEditableInputWidth($editable, value, containerWidth) {
        if (!$editable || !$editable.length) {
            return 0;
        }

        const element = $editable.get(0);
        if (!element) {
            return 0;
        }

        let width = 0;

        try {
            const rect = element.getBoundingClientRect();
            width = rect && rect.width ? rect.width : 0;
        } catch (error) {
            width = 0;
        }

        const resolved = value === undefined || value === null ? '' : String(value);
        const textWidth = measureEditableTextWidth(element, resolved) + 12;
        width = Math.max(width, textWidth);

        if (Number.isFinite(containerWidth) && containerWidth > 0) {
            width = Math.min(width, containerWidth);
        }

        if (!width) {
            width = 80;
        }

        return Math.max(Math.ceil(width), 24);
    }

    function measureEditableTextWidth(element, text) {
        const resolvedText = text && text !== '' ? text : ' ';
        let computed;

        try {
            computed = window.getComputedStyle(element);
        } catch (error) {
            computed = null;
        }

        const $tempSpan = $('<span>', {
            text: resolvedText
        }).css({
            visibility: 'hidden',
            position: 'absolute',
            height: 'auto',
            width: 'auto',
            maxWidth: 'none',
            whiteSpace: 'nowrap',
            fontFamily: computed ? computed.fontFamily : '',
            fontSize: computed ? computed.fontSize : '',
            fontWeight: computed ? computed.fontWeight : '',
            fontStyle: computed ? computed.fontStyle : '',
            letterSpacing: computed ? computed.letterSpacing : '',
            textTransform: computed ? computed.textTransform : ''
        });

        $('body').append($tempSpan);
        const measuredWidth = $tempSpan.outerWidth();
        $tempSpan.remove();

        return measuredWidth || 0;
    }

    function resizeInput($input, options) {
        if (!$input || !$input.length) {
            return;
        }

        const settings = $.extend({
            minWidth: 48,
            maxWidth: 320,
            includeExtras: true,
            padding: 0
        }, options);

        const element = $input.get(0);
        const currentValue = $input.val();
        const proposed = currentValue === '' ? ($input.attr('placeholder') || '') : currentValue;
        const computed = element ? window.getComputedStyle(element) : null;

        const $tempSpan = $('<span>', {
            text: proposed || ' '
        }).css({
            visibility: 'hidden',
            position: 'absolute',
            height: 'auto',
            width: 'auto',
            maxWidth: '320px',
            whiteSpace: 'nowrap',
            fontFamily: computed ? computed.fontFamily : '',
            fontSize: computed ? computed.fontSize : '',
            fontWeight: computed ? computed.fontWeight : '',
            fontStyle: computed ? computed.fontStyle : '',
            letterSpacing: computed ? computed.letterSpacing : '',
            textTransform: computed ? computed.textTransform : ''
        });

        $('body').append($tempSpan);
        let width = $tempSpan.outerWidth();
        $tempSpan.remove();

        if (settings.includeExtras && computed) {
            const parseDimension = function (value) {
                const parsed = parseFloat(value);
                return Number.isFinite(parsed) ? parsed : 0;
            };

            const horizontalExtras = parseDimension(computed.paddingLeft)
                + parseDimension(computed.paddingRight)
                + parseDimension(computed.borderLeftWidth)
                + parseDimension(computed.borderRightWidth);

            width += horizontalExtras;
        }

        const padding = Number.isFinite(settings.padding) ? settings.padding : 0;
        width += padding;

        const minWidth = Number.isFinite(settings.minWidth) ? settings.minWidth : 0;
        let resolvedWidth = Math.max(width, minWidth);

        if (Number.isFinite(settings.maxWidth) && settings.maxWidth > 0) {
            resolvedWidth = Math.min(resolvedWidth, settings.maxWidth);
        }

        $input.css('width', resolvedWidth);
    }

    function initMobileSidebar() {
        $(function () {
            const $toggler = $('.navbar-toggler');
            const $sidebar = $('#sidebarMenu');

            if (!$toggler.length || !$sidebar.length) {
                return;
            }

            $(document).on('click.mobileSidebar', function (event) {
                if ($(window).width() < 768) {
                    const $target = $(event.target);
                    if (!$sidebar.is(event.target) && !$sidebar.has(event.target).length && !$toggler.is(event.target) && !$toggler.has(event.target).length && $sidebar.hasClass('show')) {
                        const instance = bootstrap.Collapse.getInstance($sidebar[0]);
                        if (instance) {
                            instance.hide();
                        }
                    }
                }
            });
        });
    }

    function initTableSortable() {
        const selector = 'table.sortable';
        const $tables = $(selector);

        if (!$tables.length) {
            return;
        }

        const parseNumeric = function (input) {
            if (input === null || input === undefined) {
                return null;
            }

            let value = String(input).trim();
            if (!value) {
                return null;
            }

            if (/^\(.*\)$/.test(value)) {
                value = '-' + value.slice(1, -1);
            }

            value = value.replace(/\u2212/g, '-');
            value = value.replace(/[\s\u00A0]/g, '');

            if (value.endsWith('-') && !value.startsWith('-')) {
                value = '-' + value.slice(0, -1);
            }

            const cleaned = value.replace(/[^0-9+\-.,']/g, '');
            if (!cleaned || !/[0-9]/.test(cleaned)) {
                return null;
            }

            const match = cleaned.match(/[-+]?[\d.,']+/);
            if (!match) {
                return null;
            }

            let candidate = match[0].replace(/'/g, '');
            const lastComma = candidate.lastIndexOf(',');
            const lastDot = candidate.lastIndexOf('.');
            const hasComma = lastComma !== -1;
            const hasDot = lastDot !== -1;

            if (hasComma && !hasDot) {
                const parts = candidate.split(',');
                if (parts.length === 2 && parts[1].length > 0 && parts[1].length <= 2) {
                    candidate = parts[0].replace(/\./g, '') + '.' + parts[1];
                } else {
                    candidate = candidate.replace(/[,\.]/g, '');
                }
            } else if (hasDot && !hasComma) {
                const dotCount = (candidate.match(/\./g) || []).length;
                if (dotCount > 1) {
                    const lastSegment = candidate.slice(lastDot + 1);
                    if (lastSegment.length === 3) {
                        candidate = candidate.replace(/\./g, '');
                    } else {
                        candidate = candidate.slice(0, lastDot).replace(/\./g, '') + '.' + lastSegment;
                    }
                }
            } else if (hasComma && hasDot) {
                if (lastComma > lastDot) {
                    const withoutDots = candidate.replace(/\./g, '');
                    const parts = withoutDots.split(',');
                    const decimalPart = parts.pop();
                    candidate = parts.join('') + '.' + decimalPart;
                } else {
                    let withoutCommas = candidate.replace(/,/g, '');
                    const dotSegments = withoutCommas.split('.');
                    if (dotSegments.length > 2) {
                        const decimalPart = dotSegments.pop();
                        withoutCommas = dotSegments.join('') + '.' + decimalPart;
                    }
                    candidate = withoutCommas;
                }
            }

            const parsed = parseFloat(candidate);
            return Number.isNaN(parsed) ? null : parsed;
        };

        const parseCellValue = function ($cell, forcedType) {
            if (!$cell || !$cell.length) {
                return { type: 'empty', value: '' };
            }

            const dataValueAttr = $cell.attr('data-sort-value');
            const dataValue = dataValueAttr !== undefined ? dataValueAttr : $cell.data('sortValue');
            const raw = dataValue !== undefined ? dataValue : $cell.text();
            const stringValue = raw === null || raw === undefined ? '' : String(raw).trim();

            if (!stringValue) {
                return { type: 'empty', value: '' };
            }

            const typeHint = (forcedType || '').toLowerCase();

            if (typeHint === 'number' || typeHint === 'numeric') {
                const hintedNumber = parseNumeric(stringValue);
                if (hintedNumber !== null) {
                    return { type: 'number', value: hintedNumber };
                }
            }

            if (typeHint === 'string' || typeHint === 'text') {
                return { type: 'string', value: stringValue.toLowerCase(), display: stringValue };
            }

            const numericValue = parseNumeric(stringValue);
            if (numericValue !== null) {
                return { type: 'number', value: numericValue };
            }

            return { type: 'string', value: stringValue.toLowerCase(), display: stringValue };
        };

        const sortTableByColumn = function ($table, $header, columnIndex) {
            const $tbody = $table.find('tbody').first();
            if (!$tbody.length) {
                return;
            }

            const currentDirection = $header.data('sortDirection');
            const direction = currentDirection === 'asc' ? 'desc' : 'asc';
            const forcedType = ($header.data('sortType') || $header.attr('data-sort-type') || '').toLowerCase();
            const indicatorClass = 'sortable-indicator';
            const iconAsc = '\u25B2';
            const iconDesc = '\u25BC';

            const rows = $tbody.find('tr').get().map(function (row, index) {
                const $cells = $(row).children();
                const $cell = $cells.eq(columnIndex);
                const value = parseCellValue($cell, forcedType);
                return { element: row, value: value, index: index };
            });

            rows.sort(function (a, b) {
                const rank = { number: 1, string: 2, empty: 3 };
                const typeA = rank[a.value.type] || 99;
                const typeB = rank[b.value.type] || 99;

                if (typeA !== typeB) {
                    return direction === 'asc' ? typeA - typeB : typeB - typeA;
                }

                let diff = 0;
                if (a.value.type === 'number') {
                    diff = a.value.value - b.value.value;
                } else if (a.value.type === 'string') {
                    diff = a.value.value.localeCompare(b.value.value);
                }

                if (diff === 0) {
                    diff = a.index - b.index;
                }

                return direction === 'asc' ? diff : -diff;
            });

            rows.forEach(function (item) {
                $tbody.append(item.element);
            });

            $table.find('th').each(function () {
                const $th = $(this);
                if ($th.is($header)) {
                    return;
                }
                $th.removeClass('is-sorted-asc is-sorted-desc').removeAttr('aria-sort').data('sortDirection', null);
                $th.find('.' + indicatorClass).remove();
            });

            $header.data('sortDirection', direction);
            $header.attr('aria-sort', direction === 'asc' ? 'ascending' : 'descending');
            $header.toggleClass('is-sorted-asc', direction === 'asc');
            $header.toggleClass('is-sorted-desc', direction === 'desc');

            $header.find('.' + indicatorClass).remove();
            const $indicator = $('<span>', {
                class: indicatorClass,
                'aria-hidden': 'true',
                text: (direction === 'asc' ? ' ' + iconAsc : ' ' + iconDesc)
            });
            $header.append($indicator);
        };

        $tables.each(function () {
            const $table = $(this);
            if ($table.data('sortableInit') === '1') {
                return;
            }

            $table.data('sortableInit', '1');

            const $headers = $table.find('thead th');
            if (!$headers.length) {
                return;
            }

            $headers.each(function (columnIndex) {
                const $header = $(this);
                const sortableAttr = $header.data('sortable');
                const sortableAttrRaw = sortableAttr === undefined ? $header.attr('data-sortable') : sortableAttr;
                if (String(sortableAttrRaw).toLowerCase() === 'false') {
                    return;
                }

                if (!$header.attr('tabindex')) {
                    $header.attr('tabindex', '0');
                }

                $header.attr('role', 'button');
                $header.addClass('is-sortable');

                $header.on('click.tableSort', function (event) {
                    event.preventDefault();
                    sortTableByColumn($table, $header, columnIndex);
                });

                $header.on('keydown.tableSort', function (event) {
                    if (event.key === 'Enter' || event.key === ' ') {
                        event.preventDefault();
                        sortTableByColumn($table, $header, columnIndex);
                    }
                });
            });
        });
    }

    function initThemeToggle() {
        const $root = $('html');
        const $body = $('body');
        const $dropdownThemeToggle = $('.dropdown-theme-toggle');
        const $fallbackToggles = $('[data-theme-toggle]');
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        const storageKey = 'theme';

        if (!$dropdownThemeToggle.length && !$fallbackToggles.length) {
            return;
        }

        const getStoredTheme = function () {
            const value = localStorage.getItem(storageKey);
            if (value === 'light' || value === 'dark') {
                return value;
            }
            return null;
        };

        const setStoredTheme = function (theme) {
            if (theme === null) {
                localStorage.removeItem(storageKey);
            } else {
                localStorage.setItem(storageKey, theme);
            }
        };

        const getSystemTheme = function () {
            return mediaQuery.matches ? 'dark' : 'light';
        };

        const resolveTheme = function (preferred) {
            if (preferred === 'light' || preferred === 'dark') {
                return preferred;
            }
            return getSystemTheme();
        };

        const updateIndicators = function (resolvedTheme) {
            const $dropdownThemeIcon = $('#dropdown-theme-icon');
            const $themeText = $('#theme-text');

            if ($dropdownThemeIcon.length) {
                $dropdownThemeIcon.attr('class', resolvedTheme === 'light' ? 'fas fa-sun' : 'fas fa-moon');
            }

            if ($themeText.length) {
                $themeText.text(resolvedTheme === 'dark' ? 'Dark Mode' : 'Light Mode');
            }

            if ($dropdownThemeToggle.length) {
                $dropdownThemeToggle.attr('aria-pressed', resolvedTheme === 'dark' ? 'true' : 'false');
                $dropdownThemeToggle.attr('aria-label', resolvedTheme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
            }

            $('[data-theme-state]').each(function () {
                $(this).attr('data-theme-state', resolvedTheme);
            });
        };

        const applyTheme = function (preferred) {
            const resolved = resolveTheme(preferred);
            $root.attr('data-bs-theme', resolved);
            $body.attr('data-bs-theme', resolved);
            $body.attr('data-theme', resolved);
            updateIndicators(resolved);
        };

        const storedTheme = getStoredTheme();
        applyTheme(storedTheme);

        const toggleTheme = function () {
            const currentTheme = getStoredTheme() || resolveTheme(null);
            const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
            setStoredTheme(nextTheme);
            applyTheme(nextTheme);
        };

        $fallbackToggles.on('click.themeToggle', function (event) {
            event.preventDefault();
            const $toggle = $(this);
            const desired = $toggle.data('themeToggle') || $toggle.attr('data-theme-toggle');
            let nextTheme;
            if (desired === 'light' || desired === 'dark') {
                nextTheme = desired;
            } else {
                nextTheme = (getStoredTheme() || resolveTheme(null)) === 'dark' ? 'light' : 'dark';
            }
            setStoredTheme(nextTheme);
            applyTheme(nextTheme);
        });

        if ($dropdownThemeToggle.length) {
            $dropdownThemeToggle.on('click.themeToggle', function (event) {
                event.preventDefault();
                toggleTheme();
            });

            $dropdownThemeToggle.on('keydown.themeToggle', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    toggleTheme();
                }
            });
        }

        mediaQuery.addEventListener('change', function () {
            if (!getStoredTheme()) {
                applyTheme(null);
            }
        });
    }
})(jQuery);
