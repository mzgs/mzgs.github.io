;(function ($) {
    $(function () {
        initSidebar();
        initMobileSidebar();
        highlightActiveNavLink();
        setInlineEdits();
        initThemeToggle();
    });

    //wdwdw22
    function json_parse_clean(data) {
        const htmlDecode = function (value) {
            return $('<textarea>').html(value).text();
        };

        const clearJsonData = function (payload) {
            return payload.replace(/&quot;/g, '"');
        };

        return JSON.parse(clearJsonData(htmlDecode(data).replaceAll("'", '"')));
    }

    function scrollToTopButton() {
        const $button = $('<button>', {
            id: 'go-top-btn',
            class: 'btn btn-blue',
            html: "<i class='fas fa-arrow-up' />"
        }).css({
            position: 'fixed',
            bottom: '20px',
            right: '30px',
            zIndex: 99,
            display: 'none'
        });

        $('body').append($button);

        $(window).on('scroll', function () {
            if ($(this).scrollTop() > 20) {
                $button.show();
            } else {
                $button.hide();
            }
        });

        $button.on('click', function () {
            $('html, body').animate({ scrollTop: 0 }, 'fast');
        });
    }

    function initSidebar() {
        const $body = $('body');
        const $sidebar = $('#adminSidebar');
        const $fallbackSidebar = $('.sidebar');
        const $resolvedSidebar = $sidebar.length ? $sidebar : $fallbackSidebar;

        if (!$resolvedSidebar.length) {
            return;
        }

        const $toggleButton = $('#sidebarToggle');
        const $fallbackToggle = $('.navbar-toggler');
        const $resolvedToggle = $toggleButton.length ? $toggleButton : $fallbackToggle;
        const $closeButton = $('#sidebarClose');
        const $backdrop = $('#sidebarBackdrop');

        const openSidebar = function () {
            if ($(window).width() >= 992) {
                return;
            }
            $body.addClass('sidebar-open');
            $resolvedSidebar.addClass('open');
        };

        const closeSidebar = function () {
            $body.removeClass('sidebar-open');
            $resolvedSidebar.removeClass('open');
        };

        $resolvedToggle.on('click.sidebar', function (event) {
            event.preventDefault();
            openSidebar();
        });

        $closeButton.on('click.sidebar', function (event) {
            event.preventDefault();
            closeSidebar();
        });

        $backdrop.on('click.sidebar', closeSidebar);

        $resolvedSidebar.on('click.sidebar', 'a.nav-link', function () {
            if ($(window).width() >= 992) {
                return;
            }
            closeSidebar();
        });

        $(window).on('resize.sidebar', function () {
            if ($(window).width() >= 992) {
                closeSidebar();
            }
        });

        $(document).on('keydown.sidebar', function (event) {
            if (event.key === 'Escape') {
                closeSidebar();
            }
        });
    }

    function highlightActiveNavLink() {
        const $links = $('.sidebar a.nav-link, .sidebar a');
        if (!$links.length) {
            return;
        }

        const currentPath = normalisePath(window.location.pathname);

        $links.each(function () {
            const $link = $(this);
            const href = $link.attr('href');
            if (!href) {
                return;
            }

            let linkPath;
            try {
                linkPath = normalisePath(new URL(href, window.location.origin).pathname);
            } catch (error) {
                linkPath = normalisePath(href);
            }

            if (linkPath === currentPath) {
                $link.addClass('active').attr('aria-current', 'page');
            } else {
                $link.removeClass('active').removeAttr('aria-current');
            }
        });
    }

    function normalisePath(pathname) {
        if (!pathname) {
            return '/';
        }
        const path = pathname.split('?')[0].split('#')[0];
        if (path.length > 1 && path.endsWith('/')) {
            return path.slice(0, -1);
        }
        return path || '/';
    }

    function setInlineEdits() {
        $('.editable').each(function () {
            const $editable = $(this);

            if ($editable.data('inlineBound') === '1') {
                return;
            }

            $editable.data('inlineBound', '1').attr('data-inline-bound', '1');
            applyEditableDisplay($editable);

            $editable.on('click.inlineEdit', function () {
                if ($editable.find('.editable-input').length) {
                    return;
                }

                const updateUrl = $editable.data('updateUrl')
                    || $editable.attr('data-update-url')
                    || $editable.data('url')
                    || $editable.attr('data-url');

                if (!updateUrl) {
                    return;
                }

                const originalValue = $editable.data('value') !== undefined
                    ? $editable.data('value')
                    : $.trim($editable.text());

                const inputTypeRaw = $editable.data('inputType') || $editable.attr('data-input-type') || 'text';
                const inputType = String(inputTypeRaw).toLowerCase();
                const customInputClass = $editable.data('inputClass') || $editable.attr('data-input-class') || '';
                const inputClasses = ['editable-input'];

                if (customInputClass) {
                    inputClasses.push(customInputClass);
                } else if (inputType === 'select') {
                    inputClasses.push('form-select form-select-sm');
                }

                let $input;

                if (inputType === 'select') {
                    $input = $('<select>', {
                        class: inputClasses.join(' ').trim()
                    });

                    const options = normaliseEditableOptions(getEditableOptions($editable));
                    let hasSelected = false;
                    const originalString = originalValue === undefined || originalValue === null ? '' : String(originalValue);

                    options.forEach(function (option) {
                        if (!option) {
                            return;
                        }

                        const value = option.value === undefined || option.value === null
                            ? ''
                            : String(option.value);
                        const label = option.label === undefined || option.label === null
                            ? value
                            : String(option.label);
                        const isSelected = value === originalString;
                        if (isSelected) {
                            hasSelected = true;
                        }

                        $input.append($('<option>', {
                            value: value,
                            text: label,
                            selected: isSelected
                        }));
                    });

                    if (!hasSelected && originalString !== '') {
                        $input.prepend($('<option>', {
                            value: originalString,
                            text: originalString,
                            selected: true
                        }));
                    }
                } else {
                    $input = $('<input>', {
                        type: inputType,
                        value: originalValue,
                        class: inputClasses.join(' ').trim()
                    }).css('minWidth', '50px');
                }

                $editable.removeClass('is-placeholder').empty().append($input);
                $input.trigger('focus');

                if (inputType === 'select') {
                    let submissionStarted = false;

                    $input.on('change.inlineEdit', function () {
                        const newValue = $input.val();
                        if (String(newValue ?? '') === String(originalValue ?? '')) {
                            submissionStarted = true;
                            $editable.data('value', originalValue).attr('data-value', originalValue);
                            applyEditableDisplay($editable);
                            return;
                        }

                        submissionStarted = true;
                        const $spinner = $('<div>', { class: 'fas fa-spinner fa-spin ms-1' });
                        $editable.empty().append($spinner);

                        submitInlineUpdate($editable, updateUrl, originalValue, newValue, $spinner);
                    });

                    $input.on('blur.inlineEdit', function () {
                        if (!submissionStarted) {
                            $editable.data('value', originalValue).attr('data-value', originalValue);
                            applyEditableDisplay($editable);
                        }
                    });
                } else {
                    resizeInput($input);

                    $input.on('input.inlineEdit', function () {
                        resizeInput($input);
                    });

                    let submissionStarted = false;

                    const submitValue = function (newValue) {
                        submissionStarted = true;

                        if (String(newValue ?? '') === String(originalValue ?? '')) {
                            $editable.data('value', originalValue).attr('data-value', originalValue);
                            applyEditableDisplay($editable);
                            return;
                        }

                        const $spinner = $('<div>', { class: 'fas fa-spinner fa-spin ms-1' });
                        $editable.empty().append($spinner);
                        submitInlineUpdate($editable, updateUrl, originalValue, newValue, $spinner);
                    };

                    $input.on('keypress.inlineEdit', function (event) {
                        if (event.key === 'Enter') {
                            event.preventDefault();
                            submitValue($input.val());
                        }
                    });

                    $input.on('blur.inlineEdit', function () {
                        if (submissionStarted) {
                            return;
                        }
                        submitValue($input.val());
                    });
                }
            });
        });
    }

    function getEditableOptions($editable) {
        let options = $editable.data('options');

        if (options === undefined) {
            const attr = $editable.attr('data-options');
            if (attr !== undefined) {
                options = attr;
            }
        }

        if (options === undefined || options === null || options === '') {
            return [];
        }

        if (Array.isArray(options)) {
            return options;
        }

        if (typeof options === 'string') {
            const trimmed = options.trim();
            if (!trimmed) {
                return [];
            }

            try {
                const parsed = JSON.parse(trimmed);
                if (Array.isArray(parsed)) {
                    return parsed;
                }
            } catch (error) {
                return trimmed.split(',').map(function (item) {
                    return item.trim();
                }).filter(function (item) {
                    return item !== '';
                });
            }
        }

        if (typeof options === 'object') {
            return Object.keys(options).sort().map(function (key) {
                return options[key];
            });
        }

        return [];
    }

    function normaliseEditableOptions(options) {
        if (!Array.isArray(options)) {
            return [];
        }

        return options.reduce(function (accumulator, option) {
            if (option === null || option === undefined) {
                return accumulator;
            }

            if (typeof option === 'string' || typeof option === 'number' || typeof option === 'boolean') {
                const value = String(option);
                accumulator.push({ value: value, label: value });
                return accumulator;
            }

            if (typeof option === 'object') {
                const valueSource = Object.prototype.hasOwnProperty.call(option, 'value')
                    ? option.value
                    : (Object.prototype.hasOwnProperty.call(option, 'id') ? option.id : '');

                const value = valueSource === null || valueSource === undefined ? '' : String(valueSource);

                const labelSource = Object.prototype.hasOwnProperty.call(option, 'label')
                    ? option.label
                    : (Object.prototype.hasOwnProperty.call(option, 'text') ? option.text : null);

                const label = labelSource === null || labelSource === undefined ? value : String(labelSource);

                accumulator.push({ value: value, label: label });
            }

            return accumulator;
        }, []);
    }

    function resolveEditableDisplayValue($editable, value) {
        const options = normaliseEditableOptions(getEditableOptions($editable));

        if (options.length) {
            const match = options.find(function (option) {
                return String(option.value) === value;
            });

            if (match && match.label !== undefined) {
                return String(match.label);
            }
        }

        return value;
    }

    function submitInlineUpdate($editable, updateUrl, originalValue, newValue, $spinner) {
        const params = { value: newValue };

        $.each($editable.get(0).attributes, function (_, attr) {
            if (!attr.name.startsWith('data-')) {
                return;
            }

            const key = attr.name.slice(5);
            if (!key || key === 'update-url' || key === 'value' || key === 'empty-display' || key === 'icon-target' || key === 'input-type' || key === 'inline-bound') {
                return;
            }

            params[key] = attr.value;
        });

        if (!Object.prototype.hasOwnProperty.call(params, 'field')) {
            $spinner.remove();
            $editable.data('value', originalValue).attr('data-value', originalValue);
            applyEditableDisplay($editable);
            return;
        }

        $.ajax({
            url: updateUrl,
            method: 'POST',
            data: params,
            dataType: 'text'
        })
            .then(function (response, textStatus, jqXHR) {
                const contentType = jqXHR.getResponseHeader('content-type') || '';
                let payload;

                if (contentType.indexOf('application/json') !== -1) {
                    try {
                        payload = JSON.parse(response);
                    } catch (error) {
                        payload = { value: response };
                    }
                } else {
                    payload = { value: response };
                }

                const nextValue = Object.prototype.hasOwnProperty.call(payload, 'value')
                    ? String(payload.value ?? '')
                    : String(newValue ?? '');

                $editable.data('value', nextValue).attr('data-value', nextValue);
                applyEditableDisplay($editable);
                $spinner.remove();

                $editable.trigger('inlineedit:updated', { value: nextValue });
            })
            .fail(function (jqXHR) {
                console.error('Inline edit failed', jqXHR);
                $spinner.remove();
                $editable.data('value', originalValue).attr('data-value', originalValue);
                applyEditableDisplay($editable);

                $editable.trigger('inlineedit:error', {
                    value: originalValue,
                    error: jqXHR
                });
            });
    }

    function applyEditableDisplay($editable) {
        if ($editable.data('value') === undefined) {
            const initialValue = $.trim($editable.text());
            $editable.data('value', initialValue).attr('data-value', initialValue);
        }

        const rawValue = $editable.data('value') ?? '';
        const value = rawValue === undefined || rawValue === null ? '' : String(rawValue);
        const placeholder = $editable.data('emptyDisplay')
            || $editable.attr('data-empty-display')
            || '';
        const shouldShowPlaceholder = $.trim(value) === '' && placeholder !== '';
        const display = shouldShowPlaceholder ? placeholder : resolveEditableDisplayValue($editable, value);

        $editable.text(display).toggleClass('is-placeholder', shouldShowPlaceholder);

        updateIconPreview($editable, $.trim(value));
    }

    function updateIconPreview($editable, value) {
        const targetId = $editable.data('iconTarget') || $editable.attr('data-icon-target');
        if (!targetId) {
            return;
        }

        const $preview = $('#' + targetId);
        if (!$preview.length) {
            return;
        }

        $preview.empty();
        const $icon = $('<i>');

        if (value) {
            $icon.attr('class', value);
            $preview.removeClass('text-muted');
        } else {
            $icon.attr('class', 'fa-regular fa-circle');
            $preview.addClass('text-muted');
        }

        $preview.append($icon);
    }

    function resizeInput($input) {
        const currentValue = $input.val();
        const proposed = currentValue === '' ? ($input.attr('placeholder') || '') : currentValue;

        const $tempSpan = $('<span>', {
            text: proposed || ' '
        }).css({
            visibility: 'hidden',
            position: 'absolute',
            height: 'auto',
            width: 'auto',
            maxWidth: '256px',
            whiteSpace: 'nowrap'
        });

        $('body').append($tempSpan);
        const width = $tempSpan.outerWidth() + 16;
        $input.css('width', Math.max(width, 100));
        $tempSpan.remove();
    }

    function initMobileSidebar() {
        $(function () {
            const $toggler = $('.navbar-toggler');
            const $sidebar = $('#sidebarMenu');

            if (!$toggler.length || !$sidebar.length) {
                return;
            }

            $(document).on('click.mobileSidebar', function (event) {
                if ($(window).width() < 768) {
                    const $target = $(event.target);
                    if (!$sidebar.is(event.target) && !$sidebar.has(event.target).length && !$toggler.is(event.target) && !$toggler.has(event.target).length && $sidebar.hasClass('show')) {
                        const instance = bootstrap.Collapse.getInstance($sidebar[0]);
                        if (instance) {
                            instance.hide();
                        }
                    }
                }
            });
        });
    }

    function initThemeToggle() {
        const $root = $('html');
        const $body = $('body');
        const $dropdownThemeToggle = $('.dropdown-theme-toggle');
        const $fallbackToggles = $('[data-theme-toggle]');
        const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
        const storageKey = 'theme';

        if (!$dropdownThemeToggle.length && !$fallbackToggles.length) {
            return;
        }

        const getStoredTheme = function () {
            const value = localStorage.getItem(storageKey);
            if (value === 'light' || value === 'dark') {
                return value;
            }
            return null;
        };

        const setStoredTheme = function (theme) {
            if (theme === null) {
                localStorage.removeItem(storageKey);
            } else {
                localStorage.setItem(storageKey, theme);
            }
        };

        const getSystemTheme = function () {
            return mediaQuery.matches ? 'dark' : 'light';
        };

        const resolveTheme = function (preferred) {
            if (preferred === 'light' || preferred === 'dark') {
                return preferred;
            }
            return getSystemTheme();
        };

        const updateIndicators = function (resolvedTheme) {
            const $dropdownThemeIcon = $('#dropdown-theme-icon');
            const $themeText = $('#theme-text');

            if ($dropdownThemeIcon.length) {
                $dropdownThemeIcon.attr('class', resolvedTheme === 'light' ? 'fas fa-sun' : 'fas fa-moon');
            }

            if ($themeText.length) {
                $themeText.text(resolvedTheme === 'dark' ? 'Dark Mode' : 'Light Mode');
            }

            if ($dropdownThemeToggle.length) {
                $dropdownThemeToggle.attr('aria-pressed', resolvedTheme === 'dark' ? 'true' : 'false');
                $dropdownThemeToggle.attr('aria-label', resolvedTheme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode');
            }

            $('[data-theme-state]').each(function () {
                $(this).attr('data-theme-state', resolvedTheme);
            });
        };

        const applyTheme = function (preferred) {
            const resolved = resolveTheme(preferred);
            $root.attr('data-bs-theme', resolved);
            $body.attr('data-bs-theme', resolved);
            $body.attr('data-theme', resolved);
            updateIndicators(resolved);
        };

        const storedTheme = getStoredTheme();
        applyTheme(storedTheme);

        const toggleTheme = function () {
            const currentTheme = getStoredTheme() || resolveTheme(null);
            const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
            setStoredTheme(nextTheme);
            applyTheme(nextTheme);
        };

        $fallbackToggles.on('click.themeToggle', function (event) {
            event.preventDefault();
            const $toggle = $(this);
            const desired = $toggle.data('themeToggle') || $toggle.attr('data-theme-toggle');
            let nextTheme;
            if (desired === 'light' || desired === 'dark') {
                nextTheme = desired;
            } else {
                nextTheme = (getStoredTheme() || resolveTheme(null)) === 'dark' ? 'light' : 'dark';
            }
            setStoredTheme(nextTheme);
            applyTheme(nextTheme);
        });

        if ($dropdownThemeToggle.length) {
            $dropdownThemeToggle.on('click.themeToggle', function (event) {
                event.preventDefault();
                toggleTheme();
            });

            $dropdownThemeToggle.on('keydown.themeToggle', function (event) {
                if (event.key === 'Enter' || event.key === ' ') {
                    event.preventDefault();
                    toggleTheme();
                }
            });
        }

        mediaQuery.addEventListener('change', function () {
            if (!getStoredTheme()) {
                applyTheme(null);
            }
        });
    }
})(jQuery);
