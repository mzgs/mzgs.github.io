<?php

use Bramus\Router\Router;
use Mzgs\Core\CoreGithubUpdater;
use Mzgs\Core\Navigation\NavigationRepository;
use FastCrud\{Crud, CrudConfig, DatabaseEditor};
use PhpHelper\{DB, App, Http, Logs, AIChat, Config, Countries, TwigHelper, AuthManager, PrettyErrorHandler};
require_once 'vendor/autoload.php';


// ---- PRODUCTION ----
if (App::isProduction()) {
    PrettyErrorHandler::init(['display' => false, 'log_errors' => true]);
    DB::mysql(PROD_DB, PROD_USER, PROD_PASS);

}
// ---- LOCAL ----
else {
    App::cliMenu(DB::cliBackupRestoreOptions(LOCAL_DB, LOCAL_USER, LOCAL_PASS) +[
        "First install app" => "composer install; php index.php 2; echo 'App installed.",
        "Update core to github" => [
            'label' => 'Update core.zip on GitHub',
            'run'   => static function (): int {
                return CoreGithubUpdater::run();
            },
        ],
    ] );

    PrettyErrorHandler::init(['display' => true, 'log_errors' => false]);
    DB::mysql(LOCAL_DB, LOCAL_USER, LOCAL_PASS);
}

// Initialize authentication system
AuthManager::init();
// AuthManager::createUsersTable();
// AuthManager::register('debf2@ymail.com', '1');


// Initialize configuration system
Config::init();
// Config::createConfigTable();

// Initialize logging system
Logs::init();
// Logs::createLogsTable();

AIChat::init(['api_key' => Config::get('services.openai.api_key')]);

TwigHelper::init([ROOT . '/app/templates', ROOT . '/core/templates']);
TwigHelper::addGlobal('auth_user', AuthManager::user());
TwigHelper::addGlobal('auth_is_logged_in', AuthManager::isLoggedIn());

$siteTitle    = Config::get('site.title', 'PHP App');
$primaryColor = Config::get('theme.primary_color', '#0668D1');

TwigHelper::addGlobal('site_title', $siteTitle);
TwigHelper::addGlobal('primary_color', $primaryColor);


Crud::init(DB::pdo());
DatabaseEditor::init();
CrudConfig::$hide_table_title = true;


TwigHelper::addGlobal('navigation_groups', NavigationRepository::grouped());
TwigHelper::addFunction('country_name', function (string $code): string
{
    return Countries::nameWithFlag($code);
});

// ------ Initialize routers --------
$router = new Router();

$router->before('GET|POST|PUT|DELETE', '/admin(/.*)?', fn() => AuthManager::requireAuth(fn() => Http::redirect('/login', 302, true)));

// Set custom 404 handler
$router->set404(function ()
{
    if (!headers_sent()) {
        http_response_code(404);
    }

    echo TwigHelper::render('404.twig', ['title' => '404 - Page Not Found', 'path' => $_SERVER['REQUEST_URI'] ?? 'unknown']);
});


include  ROOT . '/core/core_routes.php';
include  ROOT . '/app/routes.php';
 

$router->run();
