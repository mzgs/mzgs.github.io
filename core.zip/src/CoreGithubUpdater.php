<?php

namespace Mzgs\Core;

use PhpHelper\Config;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use UnexpectedValueException;
use ZipArchive;

class CoreGithubUpdater
{
    private const DEFAULT_REPO = 'mzgs/mzgs.github.io';
    private const DEFAULT_BRANCH = 'main';
    private const TARGET_PATH = 'core.zip';
    private const API_ROOT = 'https://api.github.com';

    public static function run(): int
    {
        $token = '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';
        if ($token === '') {
            fwrite(STDERR, "GitHub token missing. Set GITHUB_TOKEN env var or services.github.token config.\n");
            return 1;
        }

        $repo = self::DEFAULT_REPO;
        if ($repo === '') {
            fwrite(STDERR, "GitHub repository missing. Provide via GITHUB_REPO env var or services.github.repo config.\n");
            return 1;
        }

        $branch =  self::DEFAULT_BRANCH;
        if ($branch === '') {
            $branch = self::DEFAULT_BRANCH;
        }

        if (!class_exists(ZipArchive::class)) {
            fwrite(STDERR, "ZipArchive extension not available.\n");
            return 1;
        }

        $coreDir = ROOT . DIRECTORY_SEPARATOR . 'core';
        if (!is_dir($coreDir)) {
            fwrite(STDERR, "Core directory not found at {$coreDir}.\n");
            return 1;
        }

        $zipPath = self::createArchive($coreDir);
        if ($zipPath === null) {
            return 1;
        }

        fwrite(STDOUT, "Created archive: {$zipPath}\n");

        try {
            $sha = self::findExistingSha($repo, $branch, $token);
            self::uploadArchive($repo, $branch, $token, $zipPath, $sha);
        } catch (\Throwable $throwable) {
            fwrite(STDERR, $throwable->getMessage() . "\n");
            unlink($zipPath);
            return 1;
        }

        unlink($zipPath);
        fwrite(STDOUT, "core.zip uploaded to {$repo}@{$branch}.\n");

        return 0;
    }

    private static function createArchive(string $coreDir): ?string
    {
        $zipName = 'core-' . date('Ymd-His') . '.zip';
        $zipPath = sys_get_temp_dir() . DIRECTORY_SEPARATOR . $zipName;

        $zip = new ZipArchive();
        if ($zip->open($zipPath, ZipArchive::CREATE | ZipArchive::OVERWRITE) !== true) {
            fwrite(STDERR, "Failed to create zip archive at {$zipPath}.\n");
            return null;
        }

        $iterator = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($coreDir, RecursiveDirectoryIterator::SKIP_DOTS),
            RecursiveIteratorIterator::SELF_FIRST
        );

        foreach ($iterator as $item) {
            $realPath = $item->getPathname();
            $localName = substr($realPath, strlen($coreDir) + 1);
            if ($item->isDir()) {
                if ($localName !== false && $localName !== '') {
                    $zip->addEmptyDir($localName);
                }
                continue;
            }

            if ($localName === false || $localName === '') {
                continue;
            }

            if (!$zip->addFile($realPath, $localName)) {
                $zip->close();
                unlink($zipPath);
                fwrite(STDERR, "Failed to add {$realPath} to archive.\n");
                return null;
            }
        }

        $zip->close();

        return $zipPath;
    }

    private static function findExistingSha(string $repo, string $branch, string $token): ?string
    {
        $url = sprintf('%s/repos/%s/contents/%s?ref=%s', self::API_ROOT, self::encodeRepo($repo), rawurlencode(self::TARGET_PATH), rawurlencode($branch));
        $response = self::request('GET', $url, $token);

        if ($response['status'] === 404) {
            return null;
        }

        if ($response['status'] !== 200) {
            throw new UnexpectedValueException('Unable to fetch existing core.zip metadata (HTTP ' . $response['status'] . ').');
        }

        $body = $response['body'];
        if (!is_array($body) || !isset($body['sha'])) {
            throw new UnexpectedValueException('Malformed response when reading existing core.zip metadata.');
        }

        return (string) $body['sha'];
    }

    private static function uploadArchive(string $repo, string $branch, string $token, string $zipPath, ?string $sha): void
    {
        $content = file_get_contents($zipPath);
        if ($content === false) {
            throw new UnexpectedValueException('Unable to read temporary archive.');
        }

        $payload = [
            'message' => 'Update core.zip via CLI',
            'content' => base64_encode($content),
            'branch'  => $branch,
        ];

        if ($sha !== null) {
            $payload['sha'] = $sha;
        }

        $url = sprintf('%s/repos/%s/contents/%s', self::API_ROOT, self::encodeRepo($repo), rawurlencode(self::TARGET_PATH));
        $response = self::request('PUT', $url, $token, $payload);

        if ($response['status'] < 200 || $response['status'] >= 300) {
            throw new UnexpectedValueException('Failed to upload archive (HTTP ' . $response['status'] . ').');
        }
    }

    private static function request(string $method, string $url, string $token, ?array $payload = null): array
    {
        $headers = [
            'Authorization: token ' . $token,
            'User-Agent: mzgs-php-app-cli',
            'Accept: application/vnd.github+json',
        ];

        $body = null;
        if ($payload !== null) {
            $body = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            if ($body === false) {
                throw new UnexpectedValueException('Failed to encode request payload.');
            }
            $headers[] = 'Content-Type: application/json';
        }

        $ch = curl_init($url);
        if ($ch === false) {
            throw new UnexpectedValueException('Unable to initialize curl.');
        }

        $options = [
            CURLOPT_CUSTOMREQUEST  => $method,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_HTTPHEADER     => $headers,
            CURLOPT_TIMEOUT        => 60,
        ];

        if ($body !== null) {
            $options[CURLOPT_POSTFIELDS] = $body;
        }

        curl_setopt_array($ch, $options);

        $responseBody = curl_exec($ch);
        $errno = curl_errno($ch);
        $error = curl_error($ch);
        $status = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($errno !== 0) {
            throw new UnexpectedValueException('HTTP request failed: ' . $error, $errno);
        }

        $decoded = null;
        if ($responseBody !== false && $responseBody !== '') {
            $decoded = json_decode($responseBody, true);
            if ($decoded === null && json_last_error() !== JSON_ERROR_NONE) {
                throw new UnexpectedValueException('Failed to decode response JSON: ' . json_last_error_msg());
            }
        }

        return [
            'status' => $status,
            'body'   => $decoded,
        ];
    }

    private static function encodeRepo(string $repo): string
    {
        $segments = array_filter(explode('/', $repo), static fn($segment) => $segment !== '');
        if (count($segments) < 2) {
            throw new UnexpectedValueException('Repository must be provided as "owner/name".');
        }

        return implode('/', array_map('rawurlencode', $segments));
    }
}
