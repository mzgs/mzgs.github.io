<?php

namespace Mzgs\Core\Settings;

use PhpHelper\Config;

final class SettingsPage
{
    /**
     * @var array<string, array<string, mixed>>
     */
    private static array $fields = [];

    public static function addField(string $key, array $options = []): void
    {
        $type = self::normalizeType($options['type'] ?? 'text');
        $onUpdated = $options['onUpdated'] ?? $options['on_updated'] ?? null;
        $onSaved = $options['onSaved'] ?? $options['on_saved'] ?? null;
        $options = array_merge([
            'label' => $key,
            'type' => $type,
            'default' => '',
            'label_size' => null,
            'label_icon' => '',
            'placeholder' => '',
            'help' => '',
            'options' => [],
            'rows' => 4,
            'required' => false,
            'min' => null,
            'max' => null,
            'step' => null,
            'separator' => ',',
            'onUpdated' => null,
            'onSaved' => null,
        ], $options, ['type' => $type, 'onUpdated' => $onUpdated, 'onSaved' => $onSaved]);
        unset($options['on_updated']);
        unset($options['on_saved']);

        self::$fields[$key] = $options + ['key' => $key];
    }

    public static function fields(): array
    {
        return array_values(self::$fields);
    }

    public static function fieldsForRender(array $old = []): array
    {
        $fields = [];
        foreach (self::$fields as $key => $field) {
            $type = self::normalizeType($field['type'] ?? 'text');
            $field['type'] = $type;
            $labelSize = $field['label_size'] ?? null;
            $field['label_size'] = is_string($labelSize) && trim($labelSize) !== '' ? $labelSize : null;
            $labelIcon = $field['label_icon'] ?? '';
            $field['label_icon'] = is_string($labelIcon) ? trim($labelIcon) : '';
            $value = null;
            if (array_key_exists($key, $old)) {
                $value = $old[$key];
            } else {
                $fallback = array_key_exists('default', $field) ? $field['default'] : null;
                if ($fallback !== null && !is_string($fallback)) {
                    $fallback = (string) $fallback;
                }
                $value = Config::get($key, $fallback);
            }

            $field['options'] = self::normalizeOptions($field['options'] ?? []);
            $field['input_name'] = self::buildInputName($key, $type);
            $field['value'] = self::normalizeRenderValue($value, $type, $field);
            $fields[] = $field;
        }

        return $fields;
    }

    public static function extractInput(array $input): array
    {
        $result = [];
        foreach (self::$fields as $key => $field) {
            $raw = self::getInputValue($input, $key);
            if ($raw === null && !array_key_exists(self::normalizeInputKey($key), $input) && !array_key_exists($key, $input)) {
                continue;
            }

            if ($raw === null) {
                $result[$key] = null;
                continue;
            }

            if (is_array($raw)) {
                $result[$key] = $raw;
                continue;
            }

            $value = is_scalar($raw) ? trim((string) $raw) : '';
            $result[$key] = $value;
        }

        return $result;
    }

    public static function save(array $input): void
    {
        foreach (self::$fields as $key => $field) {
            $type = self::normalizeType($field['type'] ?? 'text');
            $value = null;

            if ($type === 'divider') {
                continue;
            }

            $raw = self::getInputValue($input, $key);
            $previous = Config::get($key);

            if ($type === 'checkbox' || $type === 'toggle') {
                $value = self::isTruthy($raw) ? '1' : '0';
            } elseif ($type === 'multiselect') {
                $values = self::normalizeArrayInput($raw, (string) ($field['separator'] ?? ','));
                $value = $values ? json_encode(array_values($values)) : null;
            } elseif ($type === 'tags') {
                $separator = is_string($field['separator'] ?? null) ? (string) $field['separator'] : ',';
                $values = self::normalizeArrayInput($raw, $separator);
                $value = $values ? json_encode(array_values($values)) : null;
            } elseif ($type === 'textarea') {
                $value = is_string($raw) ? trim($raw) : '';
                $value = $value === '' ? null : $value;
            } elseif ($type === 'code') {
                $value = is_string($raw) ? $raw : '';
                $value = trim($value) === '' ? null : $value;
            } else {
                $value = is_scalar($raw) ? trim((string) $raw) : '';
                $value = $value === '' ? null : $value;
            }

            Config::set($key, $value);
            self::triggerOnUpdated($field, $key, $value, $previous);
            self::triggerOnSaved($field, $key, $value, $previous);
        }
    }

    private static function triggerOnUpdated(array $field, string $key, ?string $value, ?string $previous): void
    {
        if ($value === $previous) {
            return;
        }

        $callback = $field['onUpdated'] ?? null;
        if (!is_callable($callback)) {
            return;
        }

        self::invokeOnUpdated($callback, $key, $value, $previous, $field);
    }

    private static function triggerOnSaved(array $field, string $key, ?string $value, ?string $previous): void
    {
        $callback = $field['onSaved'] ?? null;
        if (!is_callable($callback)) {
            return;
        }

        self::invokeOnSaved($callback, $key, $value, $previous, $field);
    }

    private static function invokeOnUpdated(callable $callback, string $key, ?string $value, ?string $previous, array $field): void
    {
        $args = [$key, $value, $previous, $field];
        $count = self::resolveCallbackParamCount($callback, count($args));
        call_user_func_array($callback, array_slice($args, 0, $count));
    }

    private static function invokeOnSaved(callable $callback, string $key, ?string $value, ?string $previous, array $field): void
    {
        $args = [$key, $value, $previous, $field];
        $count = self::resolveCallbackParamCount($callback, count($args));
        call_user_func_array($callback, array_slice($args, 0, $count));
    }

    private static function resolveCallbackParamCount(callable $callback, int $max): int
    {
        $reflection = self::resolveCallbackReflection($callback);
        if ($reflection === null || $reflection->isVariadic()) {
            return $max;
        }

        return min($reflection->getNumberOfParameters(), $max);
    }

    private static function resolveCallbackReflection(callable $callback): ?\ReflectionFunctionAbstract
    {
        try {
            if ($callback instanceof \Closure) {
                return new \ReflectionFunction($callback);
            }

            if (is_array($callback)) {
                return new \ReflectionMethod($callback[0], $callback[1]);
            }

            if (is_string($callback)) {
                if (str_contains($callback, '::')) {
                    return new \ReflectionMethod($callback);
                }

                return new \ReflectionFunction($callback);
            }

            if (is_object($callback)) {
                return new \ReflectionMethod($callback, '__invoke');
            }
        } catch (\ReflectionException) {
            return null;
        }

        return null;
    }

    private static function getInputValue(array $input, string $key): mixed
    {
        if (array_key_exists($key, $input)) {
            return $input[$key];
        }

        $normalized = self::normalizeInputKey($key);
        if ($normalized !== $key && array_key_exists($normalized, $input)) {
            return $input[$normalized];
        }

        return null;
    }

    private static function normalizeInputKey(string $key): string
    {
        return str_replace(['.', ' '], '_', $key);
    }

    private static function buildInputName(string $key, string $type): string
    {
        if ($type === 'divider') {
            return '';
        }

        $name = self::normalizeInputKey($key);
        if ($type === 'multiselect') {
            return $name . '[]';
        }

        return $name;
    }

    private static function normalizeType(string $type): string
    {
        $type = strtolower(trim($type));

        $allowed = [
            'text',
            'textarea',
            'number',
            'color',
            'select',
            'checkbox',
            'toggle',
            'radio',
            'password',
            'email',
            'url',
            'date',
            'time',
            'datetime-local',
            'multiselect',
            'tags',
            'divider',
        ];
        if (!in_array($type, $allowed, true)) {
            return 'text';
        }

        return $type;
    }

    private static function normalizeOptions(array $options): array
    {
        $normalized = [];
        $isList = array_is_list($options);

        foreach ($options as $value => $label) {
            if ($isList) {
                $value = $label;
            }

            if (!is_scalar($value)) {
                continue;
            }

            if (!is_scalar($label)) {
                $label = (string) $label;
            }

            $normalized[(string) $value] = (string) $label;
        }

        return $normalized;
    }

    private static function normalizeRenderValue(mixed $value, string $type, array $field): mixed
    {
        if ($type === 'checkbox' || $type === 'toggle') {
            return self::isTruthy($value);
        }

        if ($type === 'multiselect') {
            return self::normalizeArrayValue($value);
        }

        if ($type === 'tags') {
            $tags = self::normalizeArrayValue($value);
            return $tags ? implode(', ', $tags) : '';
        }

        if ($type === 'select' || $type === 'radio') {
            if (is_array($value)) {
                $first = reset($value);
                return $first === false ? '' : (string) $first;
            }
            return $value === null ? '' : (string) $value;
        }

        if ($value === null) {
            return '';
        }

        if (is_array($value)) {
            return implode(', ', $value);
        }

        return (string) $value;
    }

    private static function normalizeArrayInput(mixed $raw, string $separator = ','): array
    {
        if (is_array($raw)) {
            $items = $raw;
        } elseif (is_scalar($raw)) {
            $items = self::splitValue((string) $raw, $separator);
        } else {
            return [];
        }

        $clean = [];
        foreach ($items as $item) {
            if (!is_scalar($item)) {
                continue;
            }

            $value = trim((string) $item);
            if ($value === '') {
                continue;
            }

            $clean[] = $value;
        }

        return array_values(array_unique($clean));
    }

    private static function splitValue(string $value, string $separator): array
    {
        $separator = trim($separator);
        if ($separator === '') {
            $separator = ',';
        }

        $pattern = '/[' . preg_quote($separator, '/') . "\\n]+/";
        $parts = preg_split($pattern, $value);
        if (!is_array($parts)) {
            return [];
        }

        return $parts;
    }

    private static function normalizeArrayValue(mixed $value): array
    {
        if (is_array($value)) {
            return self::normalizeArrayInput($value);
        }

        if (!is_scalar($value)) {
            return [];
        }

        $stringValue = trim((string) $value);
        if ($stringValue === '') {
            return [];
        }

        $decoded = json_decode($stringValue, true);
        if (is_array($decoded)) {
            return self::normalizeArrayInput($decoded);
        }

        return self::normalizeArrayInput($stringValue);
    }

    private static function isTruthy(mixed $value): bool
    {
        if (is_bool($value)) {
            return $value;
        }

        if (is_numeric($value)) {
            return (int) $value === 1;
        }

        if (!is_string($value)) {
            return false;
        }

        $value = strtolower(trim($value));
        return in_array($value, ['1', 'true', 'yes', 'on'], true);
    }
}
