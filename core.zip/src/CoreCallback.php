<?php
namespace Mzgs\Core;
class CoreCallback
{

    static function logLevelBadge($logType)
    {
        $logTypes = [
            'info'     => 'bg-info',
            'success'  => 'bg-success',
            'error'    => 'bg-danger',
            'warning'  => 'bg-warning',
            'debug'    => 'bg-secondary',
            'critical' => 'bg-dark',
        ];

        $class = isset($logTypes[$logType]) ? $logTypes[$logType] : 'bg-secondary';

        return <<<HTML
        <span class="badge rounded-pill {$class} text-light">{$logType}</span>
    HTML;
    }



}