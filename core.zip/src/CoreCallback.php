<?php
namespace Mzgs\Core;
class CoreCallback
{

    static function logLevelBadge($logType)
    {
        $logTypes = [
            'info'     => 'bg-info',
            'success'  => 'bg-success',
            'error'    => 'bg-danger',
            'warning'  => 'bg-warning',
            'debug'    => 'bg-secondary',
            'critical' => 'bg-dark',
        ];

        $class = isset($logTypes[$logType]) ? $logTypes[$logType] : 'bg-secondary';

        return <<<HTML
        <span class="badge rounded-pill {$class} text-light">{$logType}</span>
    HTML;
    }

    
static function jsonPrettyPrint($field, $json, $row, $mode)
{
    if ($json === null || $json === '') return '';

    $h = fn($s) => htmlspecialchars($s, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
    $looks = fn($v) => is_string($v) && preg_match('/^\s*(\{.*\}|\[.*\]|".*"|\'.*\')\s*$/s', $v);
    $candidates = function ($s) {
        $out = [$s];
        $t = trim($s);
        if ($t !== '' && (($t[0] === '"' && substr($t, -1) === '"') || ($t[0] === "'" && substr($t, -1) === "'"))) $out[] = substr($t, 1, -1);
        $d = htmlspecialchars_decode($s, ENT_QUOTES);
        if ($d !== $s) {
            $out[] = $d;
            $td = trim($d);
            if ($td !== '' && (($td[0] === '"' && substr($td, -1) === '"') || ($td[0] === "'" && substr($td, -1) === "'"))) $out[] = substr($td, 1, -1);
        }
        return array_values(array_unique(array_filter($out, fn($x) => $x !== null && $x !== '')));
    };
    $tryDecode = function ($s) {
        $d = json_decode($s, true);
        if (json_last_error() === JSON_ERROR_NONE) return $d;
        if (strpos($s, '\\') !== false) {
            $u = json_decode('"' . $s . '"', true);
            if (json_last_error() === JSON_ERROR_NONE && is_string($u)) {
                $d = json_decode($u, true);
                if (json_last_error() === JSON_ERROR_NONE) return $d;
            }
        }
        $n = str_replace(['\\n', '\\r', '\\t'], ["\n", "\r", "\t"], $s);
        $d = json_decode($n, true);
        return json_last_error() === JSON_ERROR_NONE ? $d : null;
    };
    $expand = null;
    $expand = function ($v) use (&$expand, $looks, $candidates, $tryDecode) {
        if (is_array($v)) { foreach ($v as $k => $i) $v[$k] = $expand($i); return $v; }
        if (!is_string($v) || trim($v) === '') return $v;
        foreach ($candidates($v) as $frag) if ($looks($frag) && ($d = $tryDecode($frag)) !== null) return $expand($d);
        return $v;
    };

    $data = json_decode($json, true);
    if (json_last_error() !== JSON_ERROR_NONE) return $h($json);

    $pretty = json_encode($expand($data), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    return '<pre style="max-height:300px;overflow:auto;">' . $h($pretty) . '</pre>';
}

    






}
